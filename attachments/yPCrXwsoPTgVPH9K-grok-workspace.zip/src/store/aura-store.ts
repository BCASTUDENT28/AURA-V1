import { create } from "zustand";
import { decideUniverse } from "@/lib/aura/decision";
import { INSTRUMENTS } from "@/lib/aura/instruments";
import { getUniverse, PAPER_OPEN, seedQuotes, stepQuotes } from "@/lib/aura/market";
import { recordClose } from "@/lib/aura/memory";
import { getNews } from "@/lib/aura/news";
import {
  checkStops,
  emptyBook,
  flattenAll,
  matchWorking,
  navOf,
  refreshDailyPnl,
  submitOrder,
  type PaperBook,
} from "@/lib/aura/paper";
import { snapshotRisk } from "@/lib/aura/risk";
import type {
  BacktestResult,
  Decision,
  Learning,
  NewsItem,
  Quote,
  RiskSnapshot,
} from "@/lib/aura/types";
import { STARTING_CASH } from "@/lib/aura/types";

const LS_KEY = "aura-paper-v1";

function loadBook(): PaperBook {
  if (typeof window === "undefined") return emptyBook();
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return emptyBook();
    return { ...emptyBook(), ...JSON.parse(raw) };
  } catch {
    return emptyBook();
  }
}

function saveBook(book: PaperBook) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(book));
  } catch {
    /* ignore */
  }
}

function makeRisk(
  killSwitch: boolean,
  book: PaperBook,
  quotes: Record<string, Quote>,
  now: number,
  lastTick: number,
  opsWindow: number[],
): RiskSnapshot {
  return snapshotRisk({
    killSwitch,
    cash: book.cash,
    positions: book.positions,
    quotes,
    dailyPnl: book.dailyPnl,
    now,
    lastTick,
    opsWindow,
    staticIpOk: true,
  });
}

const universe = getUniverse();
const initialQuotes = seedQuotes(PAPER_OPEN);
const initialSignals = decideUniverse(initialQuotes);
const initialNews = getNews(PAPER_OPEN);
const initialBook = emptyBook();
const initialRisk = makeRisk(false, initialBook, initialQuotes, PAPER_OPEN, PAPER_OPEN, []);

export interface AuraState {
  now: number;
  tickN: number;
  quotes: Record<string, Quote>;
  signals: Decision[];
  book: PaperBook;
  riskSnap: RiskSnapshot;
  learnings: Learning[];
  news: NewsItem[];
  killSwitch: boolean;
  opsWindow: number[];
  lastTick: number;
  selectedSymbol: string;
  backtest: BacktestResult | null;
  backtestBusy: boolean;
  hydrated: boolean;
  hydrate: () => void;
  tick: () => void;
  setSymbol: (s: string) => void;
  setKill: (v: boolean) => void;
  place: (input: {
    symbol: string;
    side: "BUY" | "SELL";
    qty: number;
    limitPrice: number;
    stop: number | null;
    target: number | null;
    strategyId: string | null;
  }) => { ok: boolean; message: string };
  flatten: () => void;
  resetPaper: () => void;
  setBacktest: (r: BacktestResult | null) => void;
  setBacktestBusy: (v: boolean) => void;
  risk: () => RiskSnapshot;
  nav: () => number;
}

export const useAura = create<AuraState>((set, get) => ({
  now: PAPER_OPEN,
  tickN: 0,
  quotes: initialQuotes,
  signals: initialSignals,
  book: initialBook,
  riskSnap: initialRisk,
  learnings: [],
  news: initialNews,
  killSwitch: false,
  opsWindow: [],
  lastTick: PAPER_OPEN,
  selectedSymbol: "NIFTY",
  backtest: null,
  backtestBusy: false,
  hydrated: false,
  hydrate: () => {
    if (get().hydrated) return;
    const book = loadBook();
    set({
      book,
      hydrated: true,
      riskSnap: makeRisk(get().killSwitch, book, get().quotes, get().now, get().lastTick, get().opsWindow),
    });
  },
  tick: () => {
    const s = get();
    const now = s.now + 1000;
    const quotes = stepQuotes(s.quotes, 1, now, s.tickN + 1);
    let book = matchWorking(s.book, quotes, now);
    const risk = makeRisk(s.killSwitch, book, quotes, now, now, s.opsWindow);
    const before = new Set(book.positions.map((p) => p.symbol));
    book = checkStops(book, quotes, now, risk);
    book = refreshDailyPnl(book, quotes);
    const learnings = [...s.learnings];
    for (const p of s.book.positions) {
      if (before.has(p.symbol) && !book.positions.some((x) => x.symbol === p.symbol)) {
        const q = quotes[p.symbol];
        learnings.unshift(
          recordClose({
            position: p,
            exit: q?.ltp ?? p.avgPrice,
            now,
            regime: s.signals.find((d) => d.symbol === p.symbol)?.regime.label ?? "RANGE",
          }),
        );
      }
    }
    saveBook(book);
    const tickN = s.tickN + 1;
    const signals = tickN % 8 === 0 ? decideUniverse(quotes) : s.signals;
    const riskSnap = makeRisk(s.killSwitch, book, quotes, now, now, s.opsWindow);
    set({ now, quotes, book, lastTick: now, tickN, signals, learnings, riskSnap });
  },
  setSymbol: (selectedSymbol) => set({ selectedSymbol }),
  setKill: (killSwitch) =>
    set((s) => ({
      killSwitch,
      riskSnap: makeRisk(killSwitch, s.book, s.quotes, s.now, s.lastTick, s.opsWindow),
    })),
  place: (input) => {
    const s = get();
    const risk = s.riskSnap;
    const { book, order } = submitOrder(s.book, s.quotes, risk, { ...input, now: s.now });
    const opsWindow = [s.now, ...s.opsWindow].slice(0, 40);
    saveBook(book);
    set({
      book,
      opsWindow,
      riskSnap: makeRisk(s.killSwitch, book, s.quotes, s.now, s.lastTick, opsWindow),
    });
    if (order.status === "REJECTED") return { ok: false, message: order.rejectReason ?? "Rejected" };
    if (order.status === "FILLED") return { ok: true, message: `Filled ${order.qty} ${order.symbol} @ ${order.fillPrice}` };
    return { ok: true, message: `Working limit ${order.side} ${order.qty} ${order.symbol} @ ${order.limitPrice}` };
  },
  flatten: () => {
    const s = get();
    const book = flattenAll(s.book, s.quotes, s.now, { ...s.riskSnap, canTrade: true, breaches: [] });
    saveBook(book);
    set({
      book,
      riskSnap: makeRisk(s.killSwitch, book, s.quotes, s.now, s.lastTick, s.opsWindow),
    });
  },
  resetPaper: () => {
    const book = emptyBook();
    saveBook(book);
    const s = get();
    set({
      book,
      learnings: [],
      riskSnap: makeRisk(s.killSwitch, book, s.quotes, s.now, s.lastTick, s.opsWindow),
    });
  },
  setBacktest: (backtest) => set({ backtest }),
  setBacktestBusy: (backtestBusy) => set({ backtestBusy }),
  risk: () => get().riskSnap,
  nav: () => navOf(get().book, get().quotes),
}));

export { universe, INSTRUMENTS, STARTING_CASH };
