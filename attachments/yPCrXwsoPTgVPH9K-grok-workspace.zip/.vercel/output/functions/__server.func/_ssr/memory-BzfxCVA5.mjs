import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { E as formatIst, F as useAura, v as aggregateLearnings } from "./router-RvxJo3IS.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-CI6nIXAM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/memory-BzfxCVA5.js
var import_jsx_runtime = require_jsx_runtime();
function MemoryPage() {
	const items = useAura((s) => s.learnings);
	const agg = aggregateLearnings(items);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
				children: "Trade memory"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-medium tracking-tight",
				children: "Learnings"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-muted-foreground",
				children: "Written only from paper outcomes on this desk — not seeded, not scraped, not imagined. A learning is a hypothesis with a sample size and an expiry. Similarity flags stay dark until n ≥ 5."
			})
		] }), items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "p-6 text-sm text-muted-foreground",
			children: "Empty on purpose. Close a paper trade and the outcome lands here. Until then there is nothing honest to remember."
		}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: agg.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: l.setup
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `text-xs ${l.kind === "SUCCESS" ? "text-up" : "text-down"}`,
					children: l.kind
				})]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: l.evidence
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 font-mono text-[11px] text-muted-foreground",
				children: [
					"n=",
					l.sampleSize,
					" · conf ",
					(l.confidence * 100).toFixed(0),
					"% · expires ",
					formatIst(l.expiresTs, false),
					l.sampleSize < 5 ? " · flag gated" : ""
				]
			})] })] }, l.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Raw ledger" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "grid gap-2",
			children: items.slice(0, 20).map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-baseline justify-between gap-2 border-t border-border py-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l.evidence }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-[11px] text-muted-foreground",
					children: formatIst(l.ts)
				})]
			}, l.id))
		})] })] })]
	});
}
//#endregion
export { MemoryPage as component };
