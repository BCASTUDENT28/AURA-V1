import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as createRootRoute, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as Shield, c as LayoutDashboard, d as BookOpen, f as Activity, i as Sparkles, l as FlaskConical, n as Wallet, o as NotebookPen, r as TriangleAlert, s as Newspaper, u as Ellipsis } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
import { a as Trigger, i as Root3, n as Portal, r as Provider, t as Content2 } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aura-store-Bmr8OlCl.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var inr = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	maximumFractionDigits: 0
});
var inrDec = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	minimumFractionDigits: 2,
	maximumFractionDigits: 2
});
function formatInr(n, decimals = false) {
	return (decimals ? inrDec : inr).format(n);
}
function formatInrCompact(n) {
	const abs = Math.abs(n);
	const sign = n < 0 ? "-" : "";
	if (abs >= 1e7) return `${sign}₹${(abs / 1e7).toFixed(2)} Cr`;
	if (abs >= 1e5) return `${sign}₹${(abs / 1e5).toFixed(2)} L`;
	if (abs >= 1e3) return `${sign}₹${(abs / 1e3).toFixed(1)}k`;
	return formatInr(n, true);
}
function formatPct(n, digits = 2) {
	return `${n > 0 ? "+" : ""}${(n * 100).toFixed(digits)}%`;
}
function formatNum(n, digits = 2) {
	return n.toLocaleString("en-IN", {
		minimumFractionDigits: digits,
		maximumFractionDigits: digits
	});
}
function formatPrice(n) {
	if (n >= 1e3) return n.toLocaleString("en-IN", {
		maximumFractionDigits: 2,
		minimumFractionDigits: 2
	});
	return n.toFixed(2);
}
function formatVolume(n) {
	if (n >= 1e7) return `${(n / 1e7).toFixed(2)} Cr`;
	if (n >= 1e5) return `${(n / 1e5).toFixed(2)} L`;
	if (n >= 1e3) return `${(n / 1e3).toFixed(1)}k`;
	return String(Math.round(n));
}
function formatIst(ts, withTime = true) {
	const d = new Date(ts);
	const opts = {
		timeZone: "Asia/Kolkata",
		day: "2-digit",
		month: "short",
		year: "numeric",
		...withTime ? {
			hour: "2-digit",
			minute: "2-digit",
			hour12: false
		} : {}
	};
	return new Intl.DateTimeFormat("en-IN", opts).format(d);
}
var REGIME_LABEL = {
	BULL_TREND: "Bull trend",
	BEAR_TREND: "Bear trend",
	RANGE: "Range",
	HIGH_VOL: "High volatility",
	LOW_VOL: "Low volatility",
	BREAKOUT: "Breakout",
	MEAN_REVERT: "Mean reversion",
	STRESS: "Stress"
};
var ACTION_LABEL = {
	BUY: "Buy",
	SELL: "Sell",
	HOLD: "Hold",
	SKIP: "Skip"
};
function sma(xs, n) {
	if (xs.length < n) return xs[xs.length - 1] ?? 0;
	let s = 0;
	for (let i = xs.length - n; i < xs.length; i++) s += xs[i];
	return s / n;
}
function ema(xs, n) {
	if (!xs.length) return 0;
	const k = 2 / (n + 1);
	let e = xs[0];
	for (let i = 1; i < xs.length; i++) e = xs[i] * k + e * (1 - k);
	return e;
}
function stdev(xs) {
	if (xs.length < 2) return 0;
	const m = xs.reduce((a, b) => a + b, 0) / xs.length;
	const v = xs.reduce((a, b) => a + (b - m) ** 2, 0) / (xs.length - 1);
	return Math.sqrt(v);
}
function rsi(closes, n = 14) {
	if (closes.length < n + 1) return 50;
	let gain = 0;
	let loss = 0;
	for (let i = closes.length - n; i < closes.length; i++) {
		const d = closes[i] - closes[i - 1];
		if (d >= 0) gain += d;
		else loss -= d;
	}
	const ag = gain / n;
	const al = loss / n;
	if (al === 0) return 100;
	return 100 - 100 / (1 + ag / al);
}
function atr(bars, n = 14) {
	if (bars.length < 2) return 0;
	const trs = [];
	for (let i = 1; i < bars.length; i++) {
		const b = bars[i];
		const p = bars[i - 1];
		trs.push(Math.max(b.h - b.l, Math.abs(b.h - p.c), Math.abs(b.l - p.c)));
	}
	return sma(trs, Math.min(n, trs.length));
}
function adxPack(bars, n = 14) {
	if (bars.length < n + 2) return {
		adx: 15,
		plusDi: 20,
		minusDi: 20
	};
	const plusDM = [];
	const minusDM = [];
	const tr = [];
	for (let i = 1; i < bars.length; i++) {
		const b = bars[i];
		const p = bars[i - 1];
		const up = b.h - p.h;
		const down = p.l - b.l;
		plusDM.push(up > down && up > 0 ? up : 0);
		minusDM.push(down > up && down > 0 ? down : 0);
		tr.push(Math.max(b.h - b.l, Math.abs(b.h - p.c), Math.abs(b.l - p.c)));
	}
	const trN = sma(tr, n);
	const pN = sma(plusDM, n);
	const mN = sma(minusDM, n);
	const plusDi = trN ? 100 * pN / trN : 0;
	const minusDi = trN ? 100 * mN / trN : 0;
	return {
		adx: plusDi + minusDi === 0 ? 0 : 100 * Math.abs(plusDi - minusDi) / (plusDi + minusDi),
		plusDi,
		minusDi
	};
}
function macdPack(closes) {
	const macd = ema(closes, 12) - ema(closes, 26);
	const series = [];
	let e12 = closes[0];
	let e26 = closes[0];
	const k12 = 2 / 13;
	const k26 = 2 / 27;
	for (let i = 0; i < closes.length; i++) {
		e12 = closes[i] * k12 + e12 * .8461538461538461;
		e26 = closes[i] * k26 + e26 * .9259259259259259;
		series.push(e12 - e26);
	}
	return {
		macd,
		signal: ema(series, 9)
	};
}
function vwap(bars, lookback = 20) {
	const slice = bars.slice(-lookback);
	let pv = 0;
	let vv = 0;
	for (const b of slice) {
		const tp = (b.h + b.l + b.c) / 3;
		pv += tp * b.v;
		vv += b.v;
	}
	return vv ? pv / vv : slice[slice.length - 1]?.c ?? 0;
}
function realizedVol(closes, n = 20) {
	if (closes.length < n + 1) return .15;
	const rets = [];
	for (let i = closes.length - n; i < closes.length; i++) rets.push(Math.log(closes[i] / closes[i - 1]));
	return stdev(rets) * Math.sqrt(252);
}
function computeIndicators(bars) {
	const closes = bars.map((b) => b.c);
	const vols = bars.map((b) => b.v);
	const { adx, plusDi, minusDi } = adxPack(bars);
	const { macd, signal } = macdPack(closes);
	const mid = sma(closes, 20);
	const sd = stdev(closes.slice(-20));
	const avgVol = sma(vols, 20);
	const lastVol = vols[vols.length - 1] ?? 0;
	const volSlice = vols.slice(-20);
	const vz = sd && volSlice.length ? (lastVol - avgVol) / (stdev(volSlice) || 1) : 0;
	return {
		smaFast: sma(closes, 9),
		smaSlow: sma(closes, 21),
		ema9: ema(closes, 9),
		ema21: ema(closes, 21),
		rsi: rsi(closes, 14),
		macd,
		macdSignal: signal,
		atr: atr(bars, 14),
		adx,
		plusDi,
		minusDi,
		vwap: vwap(bars, 20),
		bbUpper: mid + 2 * sd,
		bbLower: mid - 2 * sd,
		bbMid: mid,
		realizedVol: realizedVol(closes, 20),
		volumeZ: vz,
		relVolume: avgVol ? lastVol / avgVol : 1
	};
}
var INSTRUMENTS = [
	{
		symbol: "NIFTY",
		name: "Nifty 50",
		sector: "Index",
		kind: "index",
		base: 24862,
		tick: .05,
		lot: 1,
		avgVolume: 24e7
	},
	{
		symbol: "BANKNIFTY",
		name: "Nifty Bank",
		sector: "Index",
		kind: "index",
		base: 51240,
		tick: .05,
		lot: 1,
		avgVolume: 81e6
	},
	{
		symbol: "RELIANCE",
		name: "Reliance Industries",
		sector: "Energy",
		kind: "equity",
		base: 1478,
		tick: .05,
		lot: 1,
		avgVolume: 62e5
	},
	{
		symbol: "TCS",
		name: "Tata Consultancy",
		sector: "IT",
		kind: "equity",
		base: 4124,
		tick: .05,
		lot: 1,
		avgVolume: 21e5
	},
	{
		symbol: "HDFCBANK",
		name: "HDFC Bank",
		sector: "Banks",
		kind: "equity",
		base: 1682,
		tick: .05,
		lot: 1,
		avgVolume: 14e6
	},
	{
		symbol: "INFY",
		name: "Infosys",
		sector: "IT",
		kind: "equity",
		base: 1786,
		tick: .05,
		lot: 1,
		avgVolume: 68e5
	},
	{
		symbol: "ICICIBANK",
		name: "ICICI Bank",
		sector: "Banks",
		kind: "equity",
		base: 1284,
		tick: .05,
		lot: 1,
		avgVolume: 11e6
	},
	{
		symbol: "HINDUNILVR",
		name: "Hindustan Unilever",
		sector: "FMCG",
		kind: "equity",
		base: 2488,
		tick: .05,
		lot: 1,
		avgVolume: 14e5
	},
	{
		symbol: "ITC",
		name: "ITC",
		sector: "FMCG",
		kind: "equity",
		base: 492,
		tick: .05,
		lot: 1,
		avgVolume: 12e6
	},
	{
		symbol: "SBIN",
		name: "State Bank of India",
		sector: "Banks",
		kind: "equity",
		base: 812,
		tick: .05,
		lot: 1,
		avgVolume: 15e6
	},
	{
		symbol: "BHARTIARTL",
		name: "Bharti Airtel",
		sector: "Telecom",
		kind: "equity",
		base: 1648,
		tick: .05,
		lot: 1,
		avgVolume: 54e5
	},
	{
		symbol: "BAJFINANCE",
		name: "Bajaj Finance",
		sector: "Finance",
		kind: "equity",
		base: 9120,
		tick: .05,
		lot: 1,
		avgVolume: 92e4
	},
	{
		symbol: "LT",
		name: "Larsen & Toubro",
		sector: "Infra",
		kind: "equity",
		base: 3584,
		tick: .05,
		lot: 1,
		avgVolume: 18e5
	},
	{
		symbol: "HCLTECH",
		name: "HCL Technologies",
		sector: "IT",
		kind: "equity",
		base: 1688,
		tick: .05,
		lot: 1,
		avgVolume: 32e5
	},
	{
		symbol: "AXISBANK",
		name: "Axis Bank",
		sector: "Banks",
		kind: "equity",
		base: 1124,
		tick: .05,
		lot: 1,
		avgVolume: 84e5
	},
	{
		symbol: "ASIANPAINT",
		name: "Asian Paints",
		sector: "FMCG",
		kind: "equity",
		base: 2486,
		tick: .05,
		lot: 1,
		avgVolume: 11e5
	},
	{
		symbol: "MARUTI",
		name: "Maruti Suzuki",
		sector: "Auto",
		kind: "equity",
		base: 12480,
		tick: .05,
		lot: 1,
		avgVolume: 48e4
	},
	{
		symbol: "SUNPHARMA",
		name: "Sun Pharma",
		sector: "Pharma",
		kind: "equity",
		base: 1722,
		tick: .05,
		lot: 1,
		avgVolume: 24e5
	},
	{
		symbol: "TITAN",
		name: "Titan Company",
		sector: "Consumer",
		kind: "equity",
		base: 3488,
		tick: .05,
		lot: 1,
		avgVolume: 12e5
	},
	{
		symbol: "ULTRACEMCO",
		name: "UltraTech Cement",
		sector: "Cement",
		kind: "equity",
		base: 11840,
		tick: .05,
		lot: 1,
		avgVolume: 36e4
	},
	{
		symbol: "M&M",
		name: "Mahindra & Mahindra",
		sector: "Auto",
		kind: "equity",
		base: 2784,
		tick: .05,
		lot: 1,
		avgVolume: 28e5
	},
	{
		symbol: "TATAMOTORS",
		name: "Tata Motors",
		sector: "Auto",
		kind: "equity",
		base: 784,
		tick: .05,
		lot: 1,
		avgVolume: 14e6
	},
	{
		symbol: "TATASTEEL",
		name: "Tata Steel",
		sector: "Metals",
		kind: "equity",
		base: 154,
		tick: .05,
		lot: 1,
		avgVolume: 28e6
	},
	{
		symbol: "NTPC",
		name: "NTPC",
		sector: "Energy",
		kind: "equity",
		base: 412,
		tick: .05,
		lot: 1,
		avgVolume: 11e6
	},
	{
		symbol: "POWERGRID",
		name: "Power Grid",
		sector: "Energy",
		kind: "equity",
		base: 328,
		tick: .05,
		lot: 1,
		avgVolume: 94e5
	},
	{
		symbol: "ONGC",
		name: "ONGC",
		sector: "Energy",
		kind: "equity",
		base: 268,
		tick: .05,
		lot: 1,
		avgVolume: 16e6
	},
	{
		symbol: "WIPRO",
		name: "Wipro",
		sector: "IT",
		kind: "equity",
		base: 512,
		tick: .05,
		lot: 1,
		avgVolume: 72e5
	},
	{
		symbol: "CIPLA",
		name: "Cipla",
		sector: "Pharma",
		kind: "equity",
		base: 1548,
		tick: .05,
		lot: 1,
		avgVolume: 16e5
	},
	{
		symbol: "DRREDDY",
		name: "Dr. Reddy's",
		sector: "Pharma",
		kind: "equity",
		base: 1284,
		tick: .05,
		lot: 1,
		avgVolume: 84e4
	},
	{
		symbol: "JSWSTEEL",
		name: "JSW Steel",
		sector: "Metals",
		kind: "equity",
		base: 968,
		tick: .05,
		lot: 1,
		avgVolume: 42e5
	}
];
var BY_SYMBOL = Object.fromEntries(INSTRUMENTS.map((i) => [i.symbol, i]));
var SECTORS = [
	"Index",
	"Banks",
	"IT",
	"Energy",
	"Auto",
	"FMCG",
	"Pharma",
	"Metals",
	"Finance",
	"Infra",
	"Telecom",
	"Cement",
	"Consumer"
];
function getInstrument(symbol) {
	const i = BY_SYMBOL[symbol];
	if (!i) throw new Error(`Unknown instrument ${symbol}`);
	return i;
}
function hashString(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function mulberry32(seed) {
	let a = seed >>> 0;
	return function next() {
		a |= 0;
		a = a + 1831565813 | 0;
		let t = Math.imul(a ^ a >>> 15, 1 | a);
		t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
		return ((t ^ t >>> 14) >>> 0) / 4294967296;
	};
}
function gaussian(rng) {
	let u = 0;
	let v = 0;
	while (u === 0) u = rng();
	while (v === 0) v = rng();
	return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}
/** Last cash session before the paper clock (Mon 24 Aug 2026). */
var SESSION_END = Date.UTC(2026, 7, 21, 10, 0, 0);
var PAPER_OPEN = Date.UTC(2026, 7, 24, 3, 45, 0);
var REGIME_PARAMS = {
	BULL_TREND: {
		mu: 55e-5,
		sigma: .009
	},
	BEAR_TREND: {
		mu: -45e-5,
		sigma: .012
	},
	RANGE: {
		mu: 2e-5,
		sigma: .007
	},
	HIGH_VOL: {
		mu: 0,
		sigma: .018
	},
	LOW_VOL: {
		mu: 15e-5,
		sigma: .0045
	},
	BREAKOUT: {
		mu: 8e-4,
		sigma: .014
	},
	MEAN_REVERT: {
		mu: 0,
		sigma: .008
	},
	STRESS: {
		mu: -.0012,
		sigma: .028
	}
};
function nextRegime(rng, current) {
	if (rng() > .018) return current;
	const keys = Object.keys(REGIME_PARAMS);
	return keys[Math.floor(rng() * keys.length)];
}
function roundTick(px, tick) {
	return Math.max(tick, Math.round(px / tick) * tick);
}
function makeBar(t, prev, ret, rng, inst, volMult) {
	const c = roundTick(prev * (1 + ret), inst.tick);
	const wick = Math.abs(ret) + Math.abs(gaussian(rng)) * .004;
	const h = roundTick(Math.max(prev, c) * (1 + wick * (.3 + rng() * .7)), inst.tick);
	const l = roundTick(Math.min(prev, c) * (1 - wick * (.3 + rng() * .7)), inst.tick);
	const o = roundTick(prev * (1 + (rng() - .5) * Math.abs(ret) * .6), inst.tick);
	return {
		t,
		o,
		h: Math.max(o, h, c),
		l: Math.min(o, l, c),
		c,
		v: Math.max(1, Math.round(inst.avgVolume * volMult * (.55 + rng() * .9)))
	};
}
function generateDaily(inst, end) {
	const rng = mulberry32(hashString(`d:${inst.symbol}:v4`));
	let label = inst.kind === "index" ? "BULL_TREND" : "RANGE";
	let px = inst.base * (.72 + rng() * .12);
	const bars = [];
	const regimes = [];
	let t = end - 44928e6;
	for (let i = 0; i < 520; i++) {
		const day = new Date(t).getUTCDay();
		if (day === 0 || day === 6) {
			t += 864e5;
			i--;
			continue;
		}
		label = nextRegime(rng, label);
		const p = REGIME_PARAMS[label];
		const beta = inst.kind === "index" ? 1 : .7 + rng() * .6;
		const ret = (p.mu + p.sigma * gaussian(rng)) * beta;
		const volMult = label === "STRESS" || label === "HIGH_VOL" ? 1.8 : 1;
		bars.push(makeBar(t + 36e6, px, ret, rng, inst, volMult));
		regimes.push(label);
		px = bars[bars.length - 1].c;
		t += 864e5;
	}
	const last = bars[bars.length - 1];
	const scale = inst.base / last.c;
	if (Number.isFinite(scale) && scale > 0 && Math.abs(scale - 1) > .002) for (const b of bars) {
		b.o = roundTick(b.o * scale, inst.tick);
		b.h = roundTick(b.h * scale, inst.tick);
		b.l = roundTick(b.l * scale, inst.tick);
		b.c = roundTick(b.c * scale, inst.tick);
		if (b.h < b.l) {
			const t = b.h;
			b.h = b.l;
			b.l = t;
		}
		b.h = Math.max(b.h, b.o, b.c);
		b.l = Math.min(b.l, b.o, b.c);
	}
	return {
		bars,
		regimes
	};
}
function generateMinute(inst, daily) {
	const rng = mulberry32(hashString(`m:${inst.symbol}:v4`));
	const lastDays = daily.slice(-8);
	const out = [];
	for (const d of lastDays) {
		let px = d.o;
		const sessionOpen = d.t - 36e6 + 135e5;
		const dayRet = (d.c - d.o) / d.o;
		for (let i = 0; i < 75; i++) {
			const t = sessionOpen + i * 5 * 6e4;
			const ret = dayRet / 75 + gaussian(rng) * .0018;
			const bar = makeBar(t, px, ret, rng, inst, (i < 6 || i > 68 ? 1.6 : .85) / 75);
			out.push(bar);
			px = bar.c;
		}
	}
	return out;
}
var cached = null;
function getUniverse() {
	if (cached) return cached;
	const series = {};
	for (const inst of INSTRUMENTS) {
		const { bars, regimes } = generateDaily(inst, SESSION_END);
		series[inst.symbol] = {
			daily: bars,
			minute: generateMinute(inst, bars),
			regimes
		};
	}
	cached = {
		series,
		quality: {
			source: "AURA simulator / corporate-action adjusted",
			generatedAt: SESSION_END,
			missingCandles: 0,
			duplicates: 0,
			corporateActionsApplied: 4,
			timezone: "Asia/Kolkata",
			status: "PASS",
			datasetVersion: "sim-in-eq-20240821"
		}
	};
	return cached;
}
function barsOf(symbol, tf = "1D") {
	const s = getUniverse().series[symbol];
	return tf === "1D" ? s.daily : s.minute;
}
function quoteFrom(symbol, ltp, prev, ts, volume) {
	const change = ltp - prev.c;
	const spread = Math.max(.05, ltp * 15e-5);
	return {
		symbol,
		ltp,
		bid: roundTick(ltp - spread / 2, .05),
		ask: roundTick(ltp + spread / 2, .05),
		open: prev.o,
		high: Math.max(prev.h, ltp),
		low: Math.min(prev.l, ltp),
		prevClose: prev.c,
		change,
		changePct: change / prev.c,
		volume,
		ts
	};
}
function seedQuotes(now) {
	const out = {};
	for (const inst of INSTRUMENTS) {
		const daily = barsOf(inst.symbol, "1D");
		const last = daily[daily.length - 1];
		const prev = daily[daily.length - 2] ?? last;
		const change = last.c - prev.c;
		const spread = Math.max(.05, last.c * 15e-5);
		out[inst.symbol] = {
			symbol: inst.symbol,
			ltp: last.c,
			bid: roundTick(last.c - spread / 2, .05),
			ask: roundTick(last.c + spread / 2, .05),
			open: last.o,
			high: last.h,
			low: last.l,
			prevClose: prev.c,
			change,
			changePct: prev.c ? change / prev.c : 0,
			volume: last.v,
			ts: now
		};
	}
	return out;
}
function stepQuotes(quotes, dtSec, now, tick) {
	const next = { ...quotes };
	for (const inst of INSTRUMENTS) {
		const q = quotes[inst.symbol];
		const rng = mulberry32(hashString(`${inst.symbol}:${tick}`));
		const sigma = inst.kind === "index" ? 12e-5 : 22e-5;
		const shock = gaussian(rng) * sigma * Math.sqrt(Math.max(dtSec, .5));
		const ltp = roundTick(q.ltp * (1 + shock), inst.tick);
		const prev = {
			t: q.ts,
			o: q.open,
			h: Math.max(q.high, ltp),
			l: Math.min(q.low, ltp),
			c: q.prevClose,
			v: q.volume
		};
		next[inst.symbol] = quoteFrom(inst.symbol, ltp, prev, now, q.volume + Math.round(inst.avgVolume * 2e-5));
		next[inst.symbol].open = q.open;
		next[inst.symbol].high = Math.max(q.high, ltp);
		next[inst.symbol].low = Math.min(q.low, ltp);
	}
	return next;
}
function sectorReturn(quotes, sector) {
	const xs = INSTRUMENTS.filter((i) => i.sector === sector);
	if (!xs.length) return 0;
	return xs.reduce((a, i) => a + (quotes[i.symbol]?.changePct ?? 0), 0) / xs.length;
}
function classifyRegime(bars) {
	const ind = computeIndicators(bars);
	const vol = ind.realizedVol;
	const adx = ind.adx;
	let label = "RANGE";
	let notes = "ADX below trend threshold; treat as range until proven otherwise.";
	if (vol > .32) {
		label = "STRESS";
		notes = "Realized vol in the tail. Size down or skip. Stops will be noisy.";
	} else if (vol > .24) {
		label = "HIGH_VOL";
		notes = "Elevated realized vol. Widen risk bands; fade breakouts that lack volume.";
	} else if (vol < .1 && adx < 18) {
		label = "LOW_VOL";
		notes = "Compressed vol. Breakout strategies may wake up; mean-reversion still valid.";
	} else if (adx >= 25 && ind.plusDi > ind.minusDi) {
		label = "BULL_TREND";
		notes = "ADX confirms directional trend with +DI lead. Momentum/trend-follow preferred.";
	} else if (adx >= 25 && ind.minusDi > ind.plusDi) {
		label = "BEAR_TREND";
		notes = "ADX confirms directional trend with −DI lead. Don't fade without evidence.";
	} else if (adx >= 20 && ind.relVolume > 1.4 && Math.abs(ind.rsi - 50) > 12) {
		label = "BREAKOUT";
		notes = "Volume expansion with directional RSI. Breakout family has the ball.";
	} else if (adx < 20 && ind.rsi > 30 && ind.rsi < 70) {
		label = "MEAN_REVERT";
		notes = "No trend, RSI mid-band. Mean-reversion historically less punished here.";
	} else label = "RANGE";
	const trendStrength = Math.min(1, adx / 40);
	const volPercentile = Math.max(0, Math.min(1, (vol - .08) / .28));
	return {
		label,
		adx,
		realizedVol: vol,
		volPercentile,
		trendStrength,
		notes
	};
}
function regimeFits(strategyId, regime) {
	if (({
		ma_cross: [
			"BULL_TREND",
			"BEAR_TREND",
			"BREAKOUT"
		],
		vwap_rsi: [
			"BULL_TREND",
			"BREAKOUT",
			"LOW_VOL"
		],
		orb: [
			"BREAKOUT",
			"BULL_TREND",
			"BEAR_TREND",
			"HIGH_VOL"
		]
	}[strategyId] ?? []).includes(regime)) return 1;
	if (regime === "STRESS") return .15;
	if (regime === "RANGE" || regime === "MEAN_REVERT") return .45;
	return .6;
}
var memo = /* @__PURE__ */ new Map();
function feat(bars, i) {
	const ind = computeIndicators(bars.slice(Math.max(0, i - 30), i + 1));
	const c = bars[i].c;
	const p5 = bars[i - 5]?.c ?? c;
	const p20 = bars[i - 20]?.c ?? c;
	return [
		(c - p5) / p5,
		(c - p20) / p20,
		(ind.rsi - 50) / 50,
		ind.adx / 40,
		ind.realizedVol,
		Math.tanh(ind.volumeZ / 2),
		(c - ind.vwap) / (ind.atr || c * .01)
	];
}
function dist(a, b) {
	let s = 0;
	for (let i = 0; i < a.length; i++) s += (a[i] - b[i]) ** 2;
	return Math.sqrt(s);
}
function similarSetups(bars, horizon = 5, cacheKey) {
	if (cacheKey && memo.has(cacheKey)) return memo.get(cacheKey);
	if (bars.length < 80) return {
		n: 0,
		winRate: 0,
		avgReturn: 0,
		avgMae: 0,
		avgMfe: 0,
		avgHoldBars: horizon
	};
	const last = bars.length - 1;
	const target = feat(bars, last);
	const hits = [];
	for (let i = 40; i < last - horizon - 1; i += 3) {
		const d = dist(feat(bars, i), target);
		if (d < .9) hits.push({
			i,
			d
		});
	}
	hits.sort((a, b) => a.d - b.d);
	const top = hits.slice(0, 32);
	if (!top.length) {
		const empty = {
			n: 0,
			winRate: 0,
			avgReturn: 0,
			avgMae: 0,
			avgMfe: 0,
			avgHoldBars: horizon
		};
		if (cacheKey) memo.set(cacheKey, empty);
		return empty;
	}
	let wins = 0;
	let ret = 0;
	let mae = 0;
	let mfe = 0;
	for (const h of top) {
		const entry = bars[h.i].c;
		const future = bars.slice(h.i, h.i + horizon + 1);
		const r = (future[future.length - 1].c - entry) / entry;
		ret += r;
		if (r > 0) wins++;
		let min = 0;
		let max = 0;
		for (const b of future) {
			min = Math.min(min, (b.l - entry) / entry);
			max = Math.max(max, (b.h - entry) / entry);
		}
		mae += min;
		mfe += max;
	}
	const n = top.length;
	const match = {
		n,
		winRate: wins / n,
		avgReturn: ret / n,
		avgMae: mae / n,
		avgMfe: mfe / n,
		avgHoldBars: horizon
	};
	if (cacheKey) memo.set(cacheKey, match);
	return match;
}
function base(id, version, action, extra) {
	return {
		strategyId: id,
		version,
		action,
		entry: extra.entry ?? null,
		stop: extra.stop ?? null,
		target: extra.target ?? null,
		confidence: extra.confidence ?? .5,
		reason: extra.reason ?? "",
		invalidation: extra.invalidation ?? "",
		metadata: extra.metadata ?? {}
	};
}
function maCross(bars, cfg) {
	const fastN = cfg.fast ?? 9;
	const slowN = cfg.slow ?? 21;
	const slPct = cfg.slPct ?? .01;
	const rr = cfg.rr ?? 2;
	const ind = computeIndicators(bars);
	const px = bars[bars.length - 1].c;
	const prev = computeIndicators(bars.slice(0, -1));
	const crossedUp = prev.smaFast <= prev.smaSlow && ind.smaFast > ind.smaSlow;
	const crossedDn = prev.smaFast >= prev.smaSlow && ind.smaFast < ind.smaSlow;
	const alignedUp = ind.smaFast > ind.smaSlow && ind.ema9 > ind.ema21;
	const alignedDn = ind.smaFast < ind.smaSlow && ind.ema9 < ind.ema21;
	if (ind.adx < 15) return base("ma_cross", "v1", "SKIP", {
		confidence: .35,
		reason: `ADX ${ind.adx.toFixed(1)} is below 15 — crossover in a dead trend is noise.`,
		invalidation: "Wait for ADX > 18 before acting on a cross.",
		metadata: {
			adx: ind.adx,
			fast: ind.smaFast,
			slow: ind.smaSlow
		}
	});
	if (crossedUp || alignedUp && ind.rsi > 52 && ind.rsi < 72) {
		const stop = px * (1 - slPct);
		return base("ma_cross", "v1", "BUY", {
			entry: px,
			stop,
			target: px + (px - stop) * rr,
			confidence: Math.min(.82, .5 + ind.adx / 80 + (crossedUp ? .1 : 0)),
			reason: crossedUp ? `SMA ${fastN} crossed above SMA ${slowN} with ADX ${ind.adx.toFixed(1)}.` : `Fast SMA remains above slow; RSI ${ind.rsi.toFixed(0)} supports continuation.`,
			invalidation: `Close back below SMA ${slowN} or stop at ${stop.toFixed(2)}.`,
			metadata: {
				fast: fastN,
				slow: slowN,
				adx: ind.adx,
				rsi: ind.rsi
			}
		});
	}
	if (crossedDn || alignedDn && ind.rsi < 48 && ind.rsi > 28) {
		const stop = px * (1 + slPct);
		return base("ma_cross", "v1", "SELL", {
			entry: px,
			stop,
			target: px - (stop - px) * rr,
			confidence: Math.min(.8, .5 + ind.adx / 80 + (crossedDn ? .1 : 0)),
			reason: crossedDn ? `SMA ${fastN} crossed below SMA ${slowN} with ADX ${ind.adx.toFixed(1)}.` : `Fast SMA remains below slow; RSI ${ind.rsi.toFixed(0)} supports downside.`,
			invalidation: `Close back above SMA ${slowN} or stop at ${stop.toFixed(2)}.`,
			metadata: {
				fast: fastN,
				slow: slowN,
				adx: ind.adx,
				rsi: ind.rsi
			}
		});
	}
	return base("ma_cross", "v1", "HOLD", {
		confidence: .45,
		reason: "No fresh cross and RSI is mid-range. Stand aside.",
		invalidation: "A 9/21 cross with ADX > 18.",
		metadata: {
			rsi: ind.rsi,
			adx: ind.adx
		}
	});
}
function vwapRsi(bars, cfg) {
	const rsiBuy = cfg.rsiBuy ?? 55;
	const rsiSell = cfg.rsiSell ?? 45;
	const slPct = cfg.slPct ?? .01;
	const rr = cfg.rr ?? 2;
	const ind = computeIndicators(bars);
	const px = bars[bars.length - 1].c;
	const above = px > ind.vwap;
	const volOk = ind.relVolume >= 1.1;
	if (above && ind.rsi >= rsiBuy && ind.rsi <= 72 && volOk) {
		const stop = Math.min(px * (1 - slPct), ind.vwap * .997);
		return base("vwap_rsi", "v1", "BUY", {
			entry: px,
			stop,
			target: px + (px - stop) * rr,
			confidence: Math.min(.84, .48 + (ind.relVolume - 1) * .15 + (ind.rsi - 50) / 120),
			reason: `Price ${((px / ind.vwap - 1) * 100).toFixed(2)}% above VWAP, RSI ${ind.rsi.toFixed(0)}, rel volume ${ind.relVolume.toFixed(2)}.`,
			invalidation: "VWAP breakdown or RSI rolling over through 50.",
			metadata: {
				vwap: ind.vwap,
				rsi: ind.rsi,
				relVolume: ind.relVolume
			}
		});
	}
	if (!above && ind.rsi <= rsiSell && ind.rsi >= 28 && volOk) {
		const stop = Math.max(px * (1 + slPct), ind.vwap * 1.003);
		return base("vwap_rsi", "v1", "SELL", {
			entry: px,
			stop,
			target: px - (stop - px) * rr,
			confidence: Math.min(.82, .48 + (ind.relVolume - 1) * .15 + (50 - ind.rsi) / 120),
			reason: `Price below VWAP, RSI ${ind.rsi.toFixed(0)}, volume confirmation ${ind.relVolume.toFixed(2)}.`,
			invalidation: "Reclaim of VWAP or RSI crossing 50.",
			metadata: {
				vwap: ind.vwap,
				rsi: ind.rsi,
				relVolume: ind.relVolume
			}
		});
	}
	if (!volOk) return base("vwap_rsi", "v1", "SKIP", {
		confidence: .38,
		reason: `Relative volume ${ind.relVolume.toFixed(2)} is thin. VWAP breaks without volume are usually faded.`,
		invalidation: "Rel volume > 1.1 with VWAP side confirmed.",
		metadata: {
			relVolume: ind.relVolume,
			rsi: ind.rsi
		}
	});
	return base("vwap_rsi", "v1", "HOLD", {
		confidence: .42,
		reason: `RSI ${ind.rsi.toFixed(0)} not in the continuation band relative to VWAP.`,
		invalidation: "RSI hold above 55 with price over VWAP (or the inverse).",
		metadata: {
			rsi: ind.rsi,
			vwap: ind.vwap
		}
	});
}
function orb(bars, cfg) {
	const orBars = cfg.orBars ?? 3;
	const slPct = cfg.slPct ?? .008;
	const rr = cfg.rr ?? 1.5;
	if (bars.length < orBars + 5) return base("orb", "v1", "SKIP", {
		confidence: .2,
		reason: "Not enough bars to form an opening range.",
		invalidation: "Wait for the opening range to complete."
	});
	const opening = bars.slice(-20, -20 + orBars);
	const window = opening.length ? opening : bars.slice(0, orBars);
	const orh = Math.max(...window.map((b) => b.h));
	const orl = Math.min(...window.map((b) => b.l));
	const px = bars[bars.length - 1].c;
	const ind = computeIndicators(bars);
	const rangePct = (orh - orl) / ((orh + orl) / 2);
	if (rangePct > .025) return base("orb", "v1", "SKIP", {
		confidence: .33,
		reason: `Opening range ${(rangePct * 100).toFixed(2)}% is too wide — breakouts here have poor R.`,
		invalidation: "A compressed opening range (< 1.5%).",
		metadata: {
			orh,
			orl,
			rangePct
		}
	});
	if (px > orh && ind.relVolume > 1.05) {
		const stop = Math.max(orl, px * (1 - slPct));
		return base("orb", "v1", "BUY", {
			entry: px,
			stop,
			target: px + (px - stop) * rr,
			confidence: Math.min(.8, .5 + ind.relVolume * .1),
			reason: `Break of opening-range high ${orh.toFixed(2)} with rel volume ${ind.relVolume.toFixed(2)}.`,
			invalidation: `Back inside the range or stop ${stop.toFixed(2)}.`,
			metadata: {
				orh,
				orl,
				relVolume: ind.relVolume
			}
		});
	}
	if (px < orl && ind.relVolume > 1.05) {
		const stop = Math.min(orh, px * (1 + slPct));
		return base("orb", "v1", "SELL", {
			entry: px,
			stop,
			target: px - (stop - px) * rr,
			confidence: Math.min(.78, .5 + ind.relVolume * .1),
			reason: `Break of opening-range low ${orl.toFixed(2)} with volume.`,
			invalidation: `Back inside the range or stop ${stop.toFixed(2)}.`,
			metadata: {
				orh,
				orl,
				relVolume: ind.relVolume
			}
		});
	}
	return base("orb", "v1", "HOLD", {
		confidence: .4,
		reason: `Price still inside opening range ${orl.toFixed(2)}–${orh.toFixed(2)}.`,
		invalidation: "A volume-confirmed range break.",
		metadata: {
			orh,
			orl
		}
	});
}
var STRATEGIES = [
	{
		id: "ma_cross",
		name: "MA crossover",
		version: "v1",
		family: "Trend",
		summary: "9/21 SMA cross, ADX filter, ATR-aware stop. Classic, often mediocre after costs.",
		defaults: {
			fast: 9,
			slow: 21,
			slPct: .01,
			rr: 2
		},
		params: [
			{
				key: "fast",
				label: "Fast SMA",
				min: 5,
				max: 15,
				step: 1
			},
			{
				key: "slow",
				label: "Slow SMA",
				min: 18,
				max: 50,
				step: 1
			},
			{
				key: "slPct",
				label: "Stop %",
				min: .005,
				max: .02,
				step: .001
			},
			{
				key: "rr",
				label: "R:R",
				min: 1,
				max: 3,
				step: .5
			}
		],
		run: maCross
	},
	{
		id: "vwap_rsi",
		name: "VWAP + RSI",
		version: "v1",
		family: "Momentum",
		summary: "Continuation only when price, RSI and relative volume agree with VWAP side.",
		defaults: {
			rsiBuy: 55,
			rsiSell: 45,
			slPct: .01,
			rr: 2
		},
		params: [
			{
				key: "rsiBuy",
				label: "RSI buy",
				min: 50,
				max: 65,
				step: 1
			},
			{
				key: "rsiSell",
				label: "RSI sell",
				min: 35,
				max: 50,
				step: 1
			},
			{
				key: "slPct",
				label: "Stop %",
				min: .005,
				max: .02,
				step: .001
			},
			{
				key: "rr",
				label: "R:R",
				min: 1,
				max: 3,
				step: .5
			}
		],
		run: vwapRsi
	},
	{
		id: "orb",
		name: "Opening range breakout",
		version: "v1",
		family: "Breakout",
		summary: "Break of a compressed opening range with volume. Skips wide ranges.",
		defaults: {
			orBars: 3,
			slPct: .008,
			rr: 1.5
		},
		params: [
			{
				key: "orBars",
				label: "OR bars",
				min: 2,
				max: 6,
				step: 1
			},
			{
				key: "slPct",
				label: "Stop %",
				min: .004,
				max: .015,
				step: .001
			},
			{
				key: "rr",
				label: "R:R",
				min: 1,
				max: 3,
				step: .5
			}
		],
		run: orb
	}
];
var STRATEGY_BY_ID = Object.fromEntries(STRATEGIES.map((s) => [s.id, s]));
function runAllStrategies(bars) {
	return STRATEGIES.map((s) => s.run(bars, s.defaults));
}
var FEATURE_VERSION = "feat-v1";
var DATASET_VERSION = "sim-in-eq-20240821";
var MODEL_VERSION = "regime-rules-v1";
var STARTING_CASH = 1e6;
function dirProbs(sig, regime, similar) {
	let up = .33;
	let down = .33;
	if (sig.action === "BUY") up = .45 + sig.confidence * .25;
	if (sig.action === "SELL") down = .45 + sig.confidence * .25;
	if (regime.label === "BULL_TREND") up += .06;
	if (regime.label === "BEAR_TREND") down += .06;
	if (similar.n >= 12) {
		up = up * .7 + similar.winRate * .3;
		down = down * .7 + (1 - similar.winRate) * .3;
	}
	const s = up + down + .2;
	return {
		up: up / s,
		down: down / s,
		neutral: .2 / s
	};
}
function pickBest(outputs, regimeLabel) {
	const scored = outputs.map((o) => {
		const fit = regimeFits(o.strategyId, regimeLabel);
		const actionable = o.action === "BUY" || o.action === "SELL" ? 1 : .4;
		return {
			o,
			s: o.confidence * fit * actionable
		};
	});
	scored.sort((a, b) => b.s - a.s);
	return scored[0].o;
}
function decideSymbol(symbol, quote) {
	const daily = barsOf(symbol, "1D");
	const live = daily.slice();
	const last = live[live.length - 1];
	live[live.length - 1] = {
		...last,
		c: quote.ltp,
		h: Math.max(last.h, quote.ltp),
		l: Math.min(last.l, quote.ltp)
	};
	const regime = classifyRegime(live);
	const strategy = pickBest(runAllStrategies(live), regime.label);
	const similar = similarSetups(daily, 5, symbol);
	const ind = computeIndicators(live);
	const fit = regimeFits(strategy.strategyId, regime.label);
	const reasons = [];
	const contradictions = [];
	reasons.push({
		kind: "support",
		text: strategy.reason
	});
	reasons.push({
		kind: "support",
		text: `Regime: ${regime.label.replaceAll("_", " ").toLowerCase()}. ${regime.notes}`
	});
	if (similar.n >= 8) {
		const txt = `${similar.n} similar setups · win rate ${(similar.winRate * 100).toFixed(0)}% · avg ${(similar.avgReturn * 100).toFixed(2)}% over ~${similar.avgHoldBars}d`;
		(similar.winRate >= .5 ? reasons : contradictions).push({
			kind: similar.winRate >= .5 ? "support" : "contradict",
			text: txt
		});
	} else contradictions.push({
		kind: "contradict",
		text: `Only ${similar.n} historical neighbors — sample is too small to lean on.`
	});
	if (fit < .5) contradictions.push({
		kind: "contradict",
		text: `Strategy family is a poor match for ${regime.label.replaceAll("_", " ").toLowerCase()}.`
	});
	if (ind.realizedVol > .28) contradictions.push({
		kind: "contradict",
		text: "Elevated realized vol — adverse excursion risk is high."
	});
	if (strategy.action === "BUY" && ind.rsi > 72) contradictions.push({
		kind: "contradict",
		text: `RSI ${ind.rsi.toFixed(0)} is stretched for a fresh long.`
	});
	if (strategy.action === "SELL" && ind.rsi < 28) contradictions.push({
		kind: "contradict",
		text: `RSI ${ind.rsi.toFixed(0)} is stretched for a fresh short.`
	});
	let action = strategy.action;
	let confidence = strategy.confidence * (.65 + .35 * fit);
	if (similar.n >= 12 && similar.winRate < .4 && (action === "BUY" || action === "SELL")) {
		action = "SKIP";
		confidence *= .5;
		contradictions.push({
			kind: "contradict",
			text: "Similarity engine: this setup historically underperformed. SKIP."
		});
	}
	if (regime.label === "STRESS" && action !== "HOLD") {
		action = "SKIP";
		contradictions.push({
			kind: "contradict",
			text: "Stress regime — risk engine prefers no new risk."
		});
	}
	const probs = dirProbs(strategy, regime, similar);
	const rr = strategy.entry && strategy.stop && strategy.target ? Math.abs(strategy.target - strategy.entry) / Math.max(1e-9, Math.abs(strategy.entry - strategy.stop)) : null;
	let risk = "MODERATE";
	if (action === "SKIP") risk = "HIGH";
	else if (confidence > .7 && (rr ?? 0) >= 1.8 && similar.winRate >= .52) risk = "LOW";
	else if (ind.realizedVol > .24 || fit < .5) risk = "HIGH";
	getInstrument(symbol);
	return {
		id: `${symbol}-${strategy.strategyId}-${strategy.version}`,
		symbol,
		ts: quote.ts,
		action,
		probabilityUp: probs.up,
		probabilityDown: probs.down,
		probabilityNeutral: probs.neutral,
		confidence,
		risk,
		expectedRR: rr,
		entry: strategy.entry,
		stop: strategy.stop,
		target: strategy.target,
		invalidation: strategy.invalidation,
		reasons,
		contradictions,
		strategy,
		regime,
		similar,
		riskReasons: [],
		lineage: {
			strategyVersion: `${strategy.strategyId}@${strategy.version}`,
			modelVersion: MODEL_VERSION,
			featureVersion: FEATURE_VERSION,
			datasetVersion: DATASET_VERSION
		}
	};
}
function decideUniverse(quotes) {
	const out = [];
	for (const symbol of Object.keys(quotes)) {
		if (getInstrument(symbol).kind === "index") {}
		out.push(decideSymbol(symbol, quotes[symbol]));
	}
	out.sort((a, b) => {
		const rank = (x) => (x.action === "BUY" || x.action === "SELL" ? 2 : x.action === "HOLD" ? 1 : 0) * x.confidence;
		return rank(b) - rank(a);
	});
	return out;
}
var n = 1;
function recordClose(args) {
	const pnl = (args.position.side === "BUY" ? 1 : -1) * (args.exit - args.position.avgPrice) * args.position.qty;
	const risk = Math.abs(args.position.avgPrice - (args.position.stop ?? args.position.avgPrice * .99)) * args.position.qty;
	const r = risk ? pnl / risk : 0;
	const kind = r >= 0 ? "SUCCESS" : "FAILURE";
	const setup = `${args.position.strategyId ?? "discretionary"} · ${args.position.side} · ${args.regime}`;
	return {
		id: `mem-${args.now}-${n++}`,
		ts: args.now,
		kind,
		setup,
		strategyId: args.position.strategyId ?? "discretionary",
		strategyVersion: "v1",
		regime: args.regime,
		symbol: args.position.symbol,
		evidence: `${args.position.symbol} closed at ${args.exit.toFixed(2)} vs avg ${args.position.avgPrice.toFixed(2)} · R=${r.toFixed(2)}`,
		sampleSize: 1,
		confidence: .25,
		expiresTs: args.now + 7776e6,
		rMultiple: r
	};
}
function aggregateLearnings(items) {
	const map = /* @__PURE__ */ new Map();
	for (const it of items) {
		const k = `${it.strategyId}|${it.regime}|${it.kind}`;
		const arr = map.get(k) ?? [];
		arr.push(it);
		map.set(k, arr);
	}
	const out = [];
	for (const [k, arr] of map) {
		const n = arr.length;
		const avgR = arr.reduce((a, x) => a + (x.rMultiple ?? 0), 0) / n;
		const latest = arr[0];
		out.push({
			...latest,
			id: `agg-${k}`,
			sampleSize: n,
			confidence: Math.min(.75, .2 + n * .06),
			evidence: `${n} paper outcomes · avg R ${avgR.toFixed(2)} · ${latest.setup}`,
			rMultiple: avgR
		});
	}
	return out.sort((a, b) => b.sampleSize - a.sampleSize);
}
var RAW = [
	{
		headline: "RBI holds repo rate; signals data-dependent path on liquidity",
		source: "Mint",
		symbols: [
			"HDFCBANK",
			"ICICIBANK",
			"SBIN",
			"NIFTY"
		],
		event: "Macro",
		sentiment: .12,
		impact: "HIGH"
	},
	{
		headline: "Reliance commissions new KG-D6 well; Street watches capex cadence",
		source: "ET",
		symbols: ["RELIANCE"],
		event: "Guidance",
		sentiment: .18,
		impact: "MEDIUM"
	},
	{
		headline: "TCS wins multi-year European bank mandate; deal TCV not disclosed",
		source: "Business Standard",
		symbols: [
			"TCS",
			"INFY",
			"HCLTECH"
		],
		event: "Contract",
		sentiment: .34,
		impact: "MEDIUM"
	},
	{
		headline: "SEBI reiterates algo-order tagging and static-IP rules for API users",
		source: "NSE circular",
		symbols: ["NIFTY"],
		event: "Regulatory",
		sentiment: 0,
		impact: "HIGH"
	},
	{
		headline: "Maruti flags rural demand softness in two-wheeler-adjacent commentary",
		source: "CNBC-TV18",
		symbols: [
			"MARUTI",
			"M&M",
			"TATAMOTORS"
		],
		event: "Guidance",
		sentiment: -.22,
		impact: "MEDIUM"
	},
	{
		headline: "Sun Pharma US facility inspection closed without action, company says",
		source: "Reuters",
		symbols: [
			"SUNPHARMA",
			"CIPLA",
			"DRREDDY"
		],
		event: "Regulatory",
		sentiment: .28,
		impact: "MEDIUM"
	},
	{
		headline: "FII selling in banks continues for a third session; DII absorbs",
		source: "NDTV Profit",
		symbols: [
			"HDFCBANK",
			"ICICIBANK",
			"AXISBANK",
			"BANKNIFTY"
		],
		event: "Flows",
		sentiment: -.15,
		impact: "MEDIUM"
	},
	{
		headline: "NTPC board to consider commercial-paper issue; no equity dilution",
		source: "BSE filing",
		symbols: ["NTPC", "POWERGRID"],
		event: "Capital",
		sentiment: .05,
		impact: "LOW"
	},
	{
		headline: "Bharti Airtel ARPU commentary mixed as tariff hikes anniversary",
		source: "Moneycontrol",
		symbols: ["BHARTIARTL"],
		event: "Earnings",
		sentiment: -.08,
		impact: "MEDIUM"
	},
	{
		headline: "Crude slip eases OMCs; ONGC tracks the move lower in early trade",
		source: "Bloomberg",
		symbols: ["ONGC", "RELIANCE"],
		event: "Macro",
		sentiment: .1,
		impact: "LOW"
	},
	{
		headline: "IT hiring freeze chatter returns; mid-tier names more exposed",
		source: "The Hindu Business Line",
		symbols: [
			"WIPRO",
			"HCLTECH",
			"INFY"
		],
		event: "Sector",
		sentiment: -.19,
		impact: "MEDIUM"
	},
	{
		headline: "Ultratech utilisation ticks up; cement prices stable in west",
		source: "ET Now",
		symbols: ["ULTRACEMCO"],
		event: "Sector",
		sentiment: .16,
		impact: "LOW"
	},
	{
		headline: "Bajaj Finance AUM growth in line; management flags competitive NIMs",
		source: "Company",
		symbols: ["BAJFINANCE"],
		event: "Earnings",
		sentiment: .04,
		impact: "MEDIUM"
	},
	{
		headline: "Tata Steel European operations remain a drag; India spreads hold",
		source: "Reuters",
		symbols: ["TATASTEEL", "JSWSTEEL"],
		event: "Guidance",
		sentiment: -.11,
		impact: "MEDIUM"
	},
	{
		headline: "L&T mega-project pipeline cited by brokerages as FY27 support",
		source: "Kotak note",
		symbols: ["LT"],
		event: "Sector",
		sentiment: .22,
		impact: "LOW"
	}
];
function getNews(now = PAPER_OPEN) {
	const rng = mulberry32(hashString("news-v1"));
	return RAW.map((r, i) => ({
		id: `n-${i}`,
		ts: now - Math.floor(rng() * 36) * 36e5 - i * 9e5,
		headline: r.headline,
		source: r.source,
		symbols: r.symbols,
		sentiment: r.sentiment,
		event: r.event,
		impact: r.impact
	})).sort((a, b) => b.ts - a.ts);
}
var NEWS_DISCLAIMER = "Sentiment is headline-level and does not place orders. Event classification is a label, not an impact forecast.";
var DEFAULT_COST = {
	brokerageRate: 3e-4,
	brokerageCap: 20,
	sttDelivery: .001,
	sttIntradaySell: 25e-5,
	stampDelivery: 15e-5,
	stampIntraday: 3e-5,
	exchangeRate: 297e-7,
	sebiRate: 1e-6,
	gstRate: .18,
	slippageBps: 2
};
function estimateCosts(args) {
	const cfg = args.cfg ?? DEFAULT_COST;
	const { turnover, side, product } = args;
	const brokerage = Math.min(turnover * cfg.brokerageRate, cfg.brokerageCap);
	const stt = product === "DELIVERY" ? turnover * cfg.sttDelivery : side === "SELL" ? turnover * cfg.sttIntradaySell : 0;
	const stamp = side === "BUY" ? turnover * (product === "DELIVERY" ? cfg.stampDelivery : cfg.stampIntraday) : 0;
	const exchange = turnover * cfg.exchangeRate;
	const sebi = turnover * cfg.sebiRate;
	const gst = (brokerage + exchange + sebi) * cfg.gstRate;
	const slippage = turnover * (cfg.slippageBps / 1e4);
	return {
		brokerage,
		stt,
		stamp,
		exchange,
		sebi,
		gst,
		slippage,
		total: brokerage + stt + stamp + exchange + sebi + gst + slippage
	};
}
var DEFAULT_LIMITS = {
	maxPositionPct: .1,
	maxDailyLossPct: .02,
	maxExposurePct: .8,
	maxPositions: 5,
	maxSectorPct: .35,
	opsPerSec: 9,
	stopRequired: true,
	limitOnly: true,
	dataFreshMs: 5e3
};
function snapshotRisk(args) {
	const { positions, quotes, cash, dailyPnl, now, lastTick, opsWindow } = args;
	const equity = cash + positions.reduce((a, p) => {
		const ltp = quotes[p.symbol]?.ltp ?? p.avgPrice;
		return a + (p.side === "BUY" ? 1 : -1) * (ltp - p.avgPrice) * p.qty + p.avgPrice * p.qty * (p.side === "SELL" ? 0 : 1);
	}, 0);
	const nav = Math.max(equity, 1);
	const exposure = positions.reduce((a, p) => a + Math.abs(p.qty * (quotes[p.symbol]?.ltp ?? p.avgPrice)), 0);
	const breaches = [];
	if (args.killSwitch) breaches.push("Kill switch is armed — all orders blocked.");
	if (dailyPnl / 1e6 <= -DEFAULT_LIMITS.maxDailyLossPct) breaches.push("Daily loss circuit breaker.");
	if (exposure / nav > DEFAULT_LIMITS.maxExposurePct) breaches.push("Portfolio exposure cap.");
	if (positions.length >= DEFAULT_LIMITS.maxPositions) breaches.push("Max simultaneous positions.");
	const dataAge = now - lastTick;
	if (dataAge > DEFAULT_LIMITS.dataFreshMs) breaches.push("Market data is stale.");
	if (opsWindow.filter((t) => now - t < 1e3).length >= DEFAULT_LIMITS.opsPerSec) breaches.push("9 orders/sec throttle (Angel One cap).");
	if (!args.staticIpOk) breaches.push("Static IP not verified — live path sealed.");
	return {
		killSwitch: args.killSwitch,
		dailyPnl,
		dailyPnlPct: dailyPnl / STARTING_CASH,
		exposurePct: exposure / nav,
		openPositions: positions.length,
		dataAgeMs: dataAge,
		opsWindow,
		staticIpOk: args.staticIpOk ?? true,
		env: "PAPER",
		breaches,
		canTrade: breaches.length === 0
	};
}
function gateOrder(args) {
	const reasons = [...args.risk.breaches];
	if (args.type !== "LIMIT") reasons.push("Algo path is limit-orders only (NSE: no market/IOC).");
	if (DEFAULT_LIMITS.stopRequired && (args.stop == null || args.stop <= 0)) reasons.push("Stop-loss is required.");
	const inst = getInstrument(args.symbol);
	const notional = args.qty * args.limitPrice;
	const nav = STARTING_CASH;
	if (notional / nav > DEFAULT_LIMITS.maxPositionPct) reasons.push(`Position > ${(DEFAULT_LIMITS.maxPositionPct * 100).toFixed(0)}% of book.`);
	if (args.side === "BUY" && notional > args.cash) reasons.push("Insufficient cash.");
	if (args.qty <= 0) reasons.push("Quantity must be positive.");
	if (args.existingOpenOrder) reasons.push("Duplicate working order on this symbol.");
	if (!args.quotes[args.symbol]) reasons.push("No quote.");
	if ((args.positions.filter((p) => getInstrument(p.symbol).sector === inst.sector).reduce((a, p) => a + Math.abs(p.qty * (args.quotes[p.symbol]?.ltp ?? p.avgPrice)), 0) + notional) / nav > DEFAULT_LIMITS.maxSectorPct) reasons.push("Sector concentration cap.");
	if (reasons.length) return {
		ok: false,
		reasons
	};
	return { ok: true };
}
function emptyBook() {
	return {
		cash: STARTING_CASH,
		startingCash: STARTING_CASH,
		positions: [],
		orders: [],
		fills: [],
		dailyPnl: 0,
		realized: 0,
		sessionStartNav: STARTING_CASH
	};
}
function navOf(book, quotes) {
	let n = book.cash;
	for (const p of book.positions) {
		const ltp = quotes[p.symbol]?.ltp ?? p.avgPrice;
		if (p.side === "BUY") n += p.qty * ltp;
		else n += p.qty * (2 * p.avgPrice - ltp);
	}
	return n;
}
function unrealizedOf(book, quotes) {
	let u = 0;
	for (const p of book.positions) {
		const ltp = quotes[p.symbol]?.ltp ?? p.avgPrice;
		const dir = p.side === "BUY" ? 1 : -1;
		u += dir * (ltp - p.avgPrice) * p.qty;
	}
	return u;
}
var seq = 1;
var id = (p) => `${p}-${Date.now().toString(36)}-${seq++}`;
function submitOrder(book, quotes, risk, input) {
	const dup = book.orders.some((o) => o.symbol === input.symbol && o.status === "PENDING");
	const gate = gateOrder({
		symbol: input.symbol,
		side: input.side,
		qty: input.qty,
		limitPrice: input.limitPrice,
		stop: input.stop,
		type: "LIMIT",
		quotes,
		positions: book.positions,
		cash: book.cash,
		risk,
		existingOpenOrder: dup
	});
	const order = {
		id: id("ord"),
		ts: input.now,
		symbol: input.symbol,
		side: input.side,
		type: "LIMIT",
		qty: input.qty,
		limitPrice: input.limitPrice,
		status: "PENDING",
		fillPrice: null,
		costs: null,
		rejectReason: null,
		strategyId: input.strategyId,
		stop: input.stop,
		target: input.target
	};
	if (!gate.ok) {
		order.status = "REJECTED";
		order.rejectReason = gate.reasons[0] ?? "Risk rejected";
		return {
			book: {
				...book,
				orders: [order, ...book.orders]
			},
			order
		};
	}
	const q = quotes[input.symbol];
	if (!(input.side === "BUY" ? input.limitPrice >= q.ask - 1e-9 : input.limitPrice <= q.bid + 1e-9)) return {
		book: {
			...book,
			orders: [order, ...book.orders]
		},
		order
	};
	return fillOrder(book, order, q.ltp, input.now, quotes);
}
function fillOrder(book, order, px, now, _quotes) {
	const inst = getInstrument(order.symbol);
	const costs = estimateCosts({
		turnover: px * order.qty,
		side: order.side,
		product: "INTRADAY",
		kind: inst.kind
	});
	const fill = {
		id: id("f"),
		orderId: order.id,
		ts: now,
		symbol: order.symbol,
		side: order.side,
		qty: order.qty,
		price: px,
		costs
	};
	const filled = {
		...order,
		status: "FILLED",
		fillPrice: px,
		costs
	};
	let cash = book.cash - costs.total;
	let realized = book.realized;
	const positions = book.positions.map((p) => ({ ...p }));
	const idx = positions.findIndex((p) => p.symbol === order.symbol);
	const existing = idx >= 0 ? positions[idx] : null;
	if (!existing) {
		if (order.side === "BUY") cash -= px * order.qty;
		positions.push({
			symbol: order.symbol,
			qty: order.qty,
			avgPrice: px,
			side: order.side,
			stop: order.stop,
			target: order.target,
			openedTs: now,
			realized: 0,
			costs: costs.total,
			strategyId: order.strategyId
		});
	} else if (existing.side === order.side) {
		if (order.side === "BUY") cash -= px * order.qty;
		const tot = existing.qty + order.qty;
		existing.avgPrice = (existing.avgPrice * existing.qty + px * order.qty) / tot;
		existing.qty = tot;
		existing.costs += costs.total;
	} else {
		const closeQty = Math.min(existing.qty, order.qty);
		const dir = existing.side === "BUY" ? 1 : -1;
		const pnl = dir * (px - existing.avgPrice) * closeQty;
		if (existing.side === "BUY") cash += px * closeQty;
		else cash += existing.avgPrice * closeQty + dir * (px - existing.avgPrice) * closeQty;
		existing.qty -= closeQty;
		existing.realized += pnl;
		realized += pnl;
		if (existing.qty === 0) positions.splice(idx, 1);
		const remain = order.qty - closeQty;
		if (remain > 0) {
			if (order.side === "BUY") cash -= px * remain;
			positions.push({
				symbol: order.symbol,
				qty: remain,
				avgPrice: px,
				side: order.side,
				stop: order.stop,
				target: order.target,
				openedTs: now,
				realized: 0,
				costs: costs.total,
				strategyId: order.strategyId
			});
		}
	}
	return {
		book: {
			...book,
			cash,
			realized,
			positions,
			orders: [filled, ...book.orders.filter((o) => o.id !== order.id)],
			fills: [fill, ...book.fills]
		},
		order: filled
	};
}
function matchWorking(book, quotes, now) {
	let next = book;
	for (const o of book.orders.filter((x) => x.status === "PENDING")) {
		const q = quotes[o.symbol];
		if (!q) continue;
		if (o.side === "BUY" ? q.ltp <= o.limitPrice : q.ltp >= o.limitPrice) next = fillOrder(next, o, o.limitPrice, now, quotes).book;
	}
	return next;
}
function checkStops(book, quotes, now, risk) {
	let next = book;
	for (const p of [...book.positions]) {
		const q = quotes[p.symbol];
		if (!q) continue;
		const hitStop = p.stop != null && (p.side === "BUY" && q.ltp <= p.stop || p.side === "SELL" && q.ltp >= p.stop);
		const hitTgt = p.target != null && (p.side === "BUY" && q.ltp >= p.target || p.side === "SELL" && q.ltp <= p.target);
		if (hitStop || hitTgt) next = submitOrder(next, quotes, {
			...risk,
			canTrade: true,
			breaches: []
		}, {
			symbol: p.symbol,
			side: p.side === "BUY" ? "SELL" : "BUY",
			qty: p.qty,
			limitPrice: q.ltp,
			stop: p.stop,
			target: null,
			strategyId: p.strategyId,
			now
		}).book;
	}
	return next;
}
function flattenAll(book, quotes, now, risk) {
	let next = book;
	for (const p of [...book.positions]) {
		const q = quotes[p.symbol];
		if (!q) continue;
		next = submitOrder(next, quotes, {
			...risk,
			canTrade: true,
			breaches: []
		}, {
			symbol: p.symbol,
			side: p.side === "BUY" ? "SELL" : "BUY",
			qty: p.qty,
			limitPrice: q.ltp,
			stop: p.stop,
			target: null,
			strategyId: "flatten",
			now
		}).book;
	}
	return next;
}
function refreshDailyPnl(book, quotes) {
	const nav = navOf(book, quotes);
	return {
		...book,
		dailyPnl: nav - book.sessionStartNav
	};
}
var LS_KEY = "aura-paper-v1";
function loadBook() {
	if (typeof window === "undefined") return emptyBook();
	try {
		const raw = localStorage.getItem(LS_KEY);
		if (!raw) return emptyBook();
		return {
			...emptyBook(),
			...JSON.parse(raw)
		};
	} catch {
		return emptyBook();
	}
}
function saveBook(book) {
	if (typeof window === "undefined") return;
	try {
		localStorage.setItem(LS_KEY, JSON.stringify(book));
	} catch {}
}
function makeRisk(killSwitch, book, quotes, now, lastTick, opsWindow) {
	return snapshotRisk({
		killSwitch,
		cash: book.cash,
		positions: book.positions,
		quotes,
		dailyPnl: book.dailyPnl,
		now,
		lastTick,
		opsWindow,
		staticIpOk: true
	});
}
getUniverse();
var initialQuotes = seedQuotes(PAPER_OPEN);
var initialSignals = decideUniverse(initialQuotes);
var initialNews = getNews(PAPER_OPEN);
var initialBook = emptyBook();
var initialRisk = makeRisk(false, initialBook, initialQuotes, PAPER_OPEN, PAPER_OPEN, []);
var useAura = create((set, get) => ({
	now: PAPER_OPEN,
	tickN: 0,
	quotes: initialQuotes,
	signals: initialSignals,
	book: initialBook,
	riskSnap: initialRisk,
	learnings: [],
	news: initialNews,
	killSwitch: false,
	opsWindow: [],
	lastTick: PAPER_OPEN,
	selectedSymbol: "NIFTY",
	backtest: null,
	backtestBusy: false,
	hydrated: false,
	hydrate: () => {
		if (get().hydrated) return;
		const book = loadBook();
		set({
			book,
			hydrated: true,
			riskSnap: makeRisk(get().killSwitch, book, get().quotes, get().now, get().lastTick, get().opsWindow)
		});
	},
	tick: () => {
		const s = get();
		const now = s.now + 1e3;
		const quotes = stepQuotes(s.quotes, 1, now, s.tickN + 1);
		let book = matchWorking(s.book, quotes, now);
		const risk = makeRisk(s.killSwitch, book, quotes, now, now, s.opsWindow);
		const before = new Set(book.positions.map((p) => p.symbol));
		book = checkStops(book, quotes, now, risk);
		book = refreshDailyPnl(book, quotes);
		const learnings = [...s.learnings];
		for (const p of s.book.positions) if (before.has(p.symbol) && !book.positions.some((x) => x.symbol === p.symbol)) {
			const q = quotes[p.symbol];
			learnings.unshift(recordClose({
				position: p,
				exit: q?.ltp ?? p.avgPrice,
				now,
				regime: s.signals.find((d) => d.symbol === p.symbol)?.regime.label ?? "RANGE"
			}));
		}
		saveBook(book);
		const tickN = s.tickN + 1;
		const signals = tickN % 8 === 0 ? decideUniverse(quotes) : s.signals;
		const riskSnap = makeRisk(s.killSwitch, book, quotes, now, now, s.opsWindow);
		set({
			now,
			quotes,
			book,
			lastTick: now,
			tickN,
			signals,
			learnings,
			riskSnap
		});
	},
	setSymbol: (selectedSymbol) => set({ selectedSymbol }),
	setKill: (killSwitch) => set((s) => ({
		killSwitch,
		riskSnap: makeRisk(killSwitch, s.book, s.quotes, s.now, s.lastTick, s.opsWindow)
	})),
	place: (input) => {
		const s = get();
		const risk = s.riskSnap;
		const { book, order } = submitOrder(s.book, s.quotes, risk, {
			...input,
			now: s.now
		});
		const opsWindow = [s.now, ...s.opsWindow].slice(0, 40);
		saveBook(book);
		set({
			book,
			opsWindow,
			riskSnap: makeRisk(s.killSwitch, book, s.quotes, s.now, s.lastTick, opsWindow)
		});
		if (order.status === "REJECTED") return {
			ok: false,
			message: order.rejectReason ?? "Rejected"
		};
		if (order.status === "FILLED") return {
			ok: true,
			message: `Filled ${order.qty} ${order.symbol} @ ${order.fillPrice}`
		};
		return {
			ok: true,
			message: `Working limit ${order.side} ${order.qty} ${order.symbol} @ ${order.limitPrice}`
		};
	},
	flatten: () => {
		const s = get();
		const book = flattenAll(s.book, s.quotes, s.now, {
			...s.riskSnap,
			canTrade: true,
			breaches: []
		});
		saveBook(book);
		set({
			book,
			riskSnap: makeRisk(s.killSwitch, book, s.quotes, s.now, s.lastTick, s.opsWindow)
		});
	},
	resetPaper: () => {
		const book = emptyBook();
		saveBook(book);
		const s = get();
		set({
			book,
			learnings: [],
			riskSnap: makeRisk(s.killSwitch, book, s.quotes, s.now, s.lastTick, s.opsWindow)
		});
	},
	setBacktest: (backtest) => set({ backtest }),
	setBacktestBusy: (backtestBusy) => set({ backtestBusy }),
	risk: () => get().riskSnap,
	nav: () => navOf(get().book, get().quotes)
}));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-RvxJo3IS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-background px-6 text-center text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-down",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted-foreground",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-secondary text-muted-foreground",
		outline: "shadow-[var(--shadow-border)] text-muted-foreground",
		buy: "bg-up/15 text-up",
		sell: "bg-down/15 text-down",
		hold: "bg-secondary text-muted-foreground",
		skip: "bg-warn/15 text-warn",
		paper: "bg-primary/10 text-primary"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({
			variant,
			className
		})),
		...props
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-10 shrink-0 items-center rounded-full bg-secondary shadow-[var(--shadow-border)] data-[state=checked]:bg-primary", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "block size-5 translate-x-0.5 rounded-full bg-foreground transition-transform duration-150 ease-out data-[state=checked]:translate-x-[18px] data-[state=checked]:bg-primary-foreground" })
	});
}
var TooltipProvider = Provider;
var Tooltip = Root3;
var TooltipTrigger = Trigger;
function TooltipContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
		sideOffset: 6,
		className: cn("z-50 max-w-xs rounded-md bg-popover px-2.5 py-1.5 text-xs text-popover-foreground shadow-[var(--shadow-border)]", className),
		...props
	}) });
}
function Signed({ value, pct = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("font-mono tabular-nums", value > 1e-9 ? "text-up" : value < -1e-9 ? "text-down" : "text-muted-foreground", className),
		children: pct ? formatPct(value) : `${value > 0 ? "+" : ""}${formatNum(value)}`
	});
}
function Price({ value, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("font-mono tabular-nums", className),
		children: formatPrice(value)
	});
}
function ActionChip({ action }) {
	const map = {
		BUY: "bg-up/15 text-up",
		SELL: "bg-down/15 text-down",
		HOLD: "bg-secondary text-muted-foreground",
		SKIP: "bg-warn/15 text-warn"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex rounded-full px-2 py-0.5 text-[11px] font-medium", map[action] ?? map.HOLD),
		children: action
	});
}
var NAV = [
	{
		to: "/",
		label: "Overview",
		icon: LayoutDashboard
	},
	{
		to: "/signals",
		label: "Signals",
		icon: Activity
	},
	{
		to: "/lab",
		label: "Strategy lab",
		icon: FlaskConical
	},
	{
		to: "/paper",
		label: "Paper",
		icon: NotebookPen
	},
	{
		to: "/portfolio",
		label: "Portfolio",
		icon: Wallet
	},
	{
		to: "/risk",
		label: "Risk",
		icon: Shield
	},
	{
		to: "/memory",
		label: "Memory",
		icon: BookOpen
	},
	{
		to: "/news",
		label: "News",
		icon: Newspaper
	},
	{
		to: "/research",
		label: "Research",
		icon: Sparkles
	}
];
function AppShell({ children }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const hydrate = useAura((s) => s.hydrate);
	const tick = useAura((s) => s.tick);
	const now = useAura((s) => s.now);
	const nifty = useAura((s) => s.quotes.NIFTY);
	const bank = useAura((s) => s.quotes.BANKNIFTY);
	const kill = useAura((s) => s.killSwitch);
	const setKill = useAura((s) => s.setKill);
	const nav = useAura((s) => s.nav());
	const daily = useAura((s) => s.book.dailyPnl);
	(0, import_react.useEffect)(() => {
		hydrate();
		const id = window.setInterval(() => tick(), 1e3);
		return () => window.clearInterval(id);
	}, [hydrate, tick]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 200,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "tape min-h-dvh bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#main",
					className: "sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-card focus:p-3",
					children: "Skip to content"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-3 py-2 lg:px-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/",
								className: "flex items-center gap-2 pr-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
										viewBox: "0 0 32 32",
										className: "size-5",
										"aria-hidden": true,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
												x: "15",
												y: "4",
												width: "2",
												height: "5",
												fill: "currentColor"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
												x: "8",
												y: "9",
												width: "6",
												height: "18",
												fill: "currentColor"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
												x: "18",
												y: "9",
												width: "6",
												height: "18",
												fill: "currentColor"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
												x: "8",
												y: "16",
												width: "16",
												height: "4",
												fill: "currentColor"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "leading-tight",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-sm font-semibold tracking-[0.18em]",
										children: "AURA"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden text-[10px] uppercase tracking-[0.16em] text-muted-foreground sm:block",
										children: "Paper desk"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "paper",
								children: "PAPER"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden items-center gap-4 md:flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, {
									symbol: "NIFTY",
									q: nifty
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tape, {
									symbol: "BANKNIFTY",
									q: bank
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "hidden text-right sm:block",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-mono text-xs tabular-nums",
											children: formatInrCompact(nav)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[10px] text-muted-foreground",
											children: ["Day ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, {
												value: daily / 1e6,
												pct: true
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "flex h-10 items-center gap-2 rounded-md px-2 hover:bg-accent",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden text-[11px] uppercase tracking-[0.12em] text-muted-foreground lg:inline",
												children: "Kill"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
												checked: kill,
												onCheckedChange: setKill,
												"aria-label": "Kill switch"
											})]
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "Halts all new paper orders. Positions stay until you flatten." })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "hidden font-mono text-[11px] tabular-nums text-muted-foreground lg:block",
										children: [formatIst(now), " IST"]
									})
								]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "sticky top-[53px] hidden h-[calc(100dvh-53px)] w-52 shrink-0 flex-col border-r border-border p-3 lg:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "grid gap-0.5",
							children: NAV.map((item) => {
								const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
								const Icon = item.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: item.to,
									className: cn("flex h-10 items-center gap-2.5 rounded-lg px-2.5 text-sm", active ? "bg-accent text-foreground" : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
								}, item.to);
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-auto px-2 pt-6 text-[11px] leading-relaxed text-muted-foreground",
							children: "Simulated Indian cash tape. No live orders. No return guarantee. Risk engine has veto."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						id: "main",
						className: "min-w-0 flex-1 px-3 py-4 pb-24 lg:px-6 lg:pb-8",
						children
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] lg:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-5",
						children: [
							NAV[0],
							NAV[1],
							NAV[2],
							NAV[3],
							{
								to: "/more",
								label: "More",
								icon: Ellipsis
							}
						].map((item) => {
							const active = item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
							const Icon = item.icon;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[10px]", active ? "text-foreground" : "text-muted-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label.replace("Strategy lab", "Lab")]
							}, item.to);
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "bottom-right"
				})
			]
		})
	});
}
function Tape({ symbol, q }) {
	if (!q) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline gap-2 font-mono text-xs tabular-nums",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground",
				children: symbol
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: q.ltp.toLocaleString("en-IN", { maximumFractionDigits: 2 }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: q.changePct >= 0 ? "text-up" : "text-down",
				children: formatPct(q.changePct)
			})
		]
	});
}
var styles_default = "/assets/styles-CjhqN_Eq.css";
var APP_NAME = "AURA";
var Route$10 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "AURA — Indian market intelligence. Paper trading, not a crystal ball."
			},
			{
				name: "theme-color",
				content: "#090A0C"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:wght@400;500;600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$9 = () => import("./routes-ee5w9rFx.mjs");
var Route$9 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./lab-DRHvFDZp.mjs");
var Route$8 = createFileRoute("/lab")({
	validateSearch: (s) => ({
		symbol: typeof s.symbol === "string" ? s.symbol : void 0,
		strategy: typeof s.strategy === "string" ? s.strategy : void 0
	}),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./memory-BzfxCVA5.mjs");
var Route$7 = createFileRoute("/memory")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./more-B3TbPLLN.mjs");
var Route$6 = createFileRoute("/more")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./news-BZWP9FEm.mjs");
var Route$5 = createFileRoute("/news")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./paper-BWrZ9ES3.mjs");
var Route$4 = createFileRoute("/paper")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./portfolio-48IVAVRe.mjs");
var Route$3 = createFileRoute("/portfolio")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./research-CyzXLWfv.mjs");
var Route$2 = createFileRoute("/research")({
	validateSearch: (s) => ({ symbol: typeof s.symbol === "string" ? s.symbol : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./risk-BB_Wf0kf.mjs");
var Route$1 = createFileRoute("/risk")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./signals-DYU-d2XH.mjs");
var Route = createFileRoute("/signals")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$9.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$10
	}),
	LabRoute: Route$8.update({
		id: "/lab",
		path: "/lab",
		getParentRoute: () => Route$10
	}),
	MemoryRoute: Route$7.update({
		id: "/memory",
		path: "/memory",
		getParentRoute: () => Route$10
	}),
	MoreRoute: Route$6.update({
		id: "/more",
		path: "/more",
		getParentRoute: () => Route$10
	}),
	NewsRoute: Route$5.update({
		id: "/news",
		path: "/news",
		getParentRoute: () => Route$10
	}),
	PaperRoute: Route$4.update({
		id: "/paper",
		path: "/paper",
		getParentRoute: () => Route$10
	}),
	PortfolioRoute: Route$3.update({
		id: "/portfolio",
		path: "/portfolio",
		getParentRoute: () => Route$10
	}),
	ResearchRoute: Route$2.update({
		id: "/research",
		path: "/research",
		getParentRoute: () => Route$10
	}),
	RiskRoute: Route$1.update({
		id: "/risk",
		path: "/risk",
		getParentRoute: () => Route$10
	}),
	SignalsRoute: Route.update({
		id: "/signals",
		path: "/signals",
		getParentRoute: () => Route$10
	})
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { getInstrument as A, estimateCosts as C, formatPct as D, formatIst as E, useAura as F, navOf as M, sectorReturn as N, formatPrice as O, unrealizedOf as P, computeIndicators as S, formatInrCompact as T, STRATEGY_BY_ID as _, Price as a, classifyRegime as b, Badge as c, INSTRUMENTS as d, NEWS_DISCLAIMER as f, STRATEGIES as g, STARTING_CASH as h, ActionChip as i, getUniverse as j, formatVolume as k, ACTION_LABEL as l, SECTORS as m, Route$2 as n, Signed as o, REGIME_LABEL as p, Route$8 as r, Switch as s, router_exports as t, DEFAULT_LIMITS as u, aggregateLearnings as v, formatInr as w, cn as x, barsOf as y };
