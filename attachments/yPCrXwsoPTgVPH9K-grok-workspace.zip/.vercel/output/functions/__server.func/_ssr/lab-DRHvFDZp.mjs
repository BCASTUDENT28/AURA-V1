import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as getInstrument, C as estimateCosts, D as formatPct, F as useAura, T as formatInrCompact, _ as STRATEGY_BY_ID, b as classifyRegime, d as INSTRUMENTS, g as STRATEGIES, h as STARTING_CASH, o as Signed, r as Route$8, w as formatInr, x as cn, y as barsOf } from "./router-RvxJo3IS.mjs";
import { t as Button } from "./button-tfFoUuRd.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-CI6nIXAM.mjs";
import { a as Area, c as ResponsiveContainer, i as XAxis, l as Tooltip, r as YAxis, t as AreaChart } from "../_libs/recharts+[...].mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab-DRHvFDZp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EquityChart({ data }) {
	const rows = data.map((d) => ({
		t: new Date(d.t).toISOString().slice(0, 10),
		v: Math.round(d.v)
	}));
	const color = (rows[rows.length - 1]?.v ?? 0) >= (rows[0]?.v ?? 0) ? "#5dba87" : "#d4676f";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-48 w-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
			width: "100%",
			height: "100%",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
				data: rows,
				margin: {
					top: 8,
					right: 8,
					left: 0,
					bottom: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: "eq",
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0%",
							stopColor: color,
							stopOpacity: .28
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "100%",
							stopColor: color,
							stopOpacity: 0
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
						dataKey: "t",
						hide: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
						hide: true,
						domain: ["auto", "auto"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
						contentStyle: {
							background: "#14171d",
							border: "1px solid #23262e",
							borderRadius: 8,
							fontSize: 12
						},
						formatter: (v) => [formatInrCompact(v), "Equity"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
						type: "monotone",
						dataKey: "v",
						stroke: color,
						fill: "url(#eq)",
						strokeWidth: 1.6
					})
				]
			})
		})
	});
}
var Tabs = Root2;
function TabsList({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
		className: cn("inline-flex h-10 items-center gap-1 rounded-lg bg-secondary p-1", className),
		...props
	});
}
function TabsTrigger({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
		className: cn("inline-flex h-8 items-center rounded-md px-3 text-xs font-medium text-muted-foreground data-[state=active]:bg-card data-[state=active]:text-foreground data-[state=active]:shadow-[var(--shadow-border)]", className),
		...props
	});
}
var TabsContent = Content;
function metricsOf(trades, equity, from, to) {
	const wins = trades.filter((t) => t.pnl > 0);
	const losses = trades.filter((t) => t.pnl <= 0);
	const netPnl = trades.reduce((a, t) => a + t.pnl, 0);
	const start = equity[0]?.v ?? 1e6;
	const end = equity[equity.length - 1]?.v ?? start;
	const totalReturn = start ? (end - start) / start : 0;
	const years = Math.max(1 / 252, (to - from) / 315576e5);
	const cagr = years > 0 ? Math.pow(Math.max(1e-9, 1 + totalReturn), 1 / years) - 1 : 0;
	const grossWin = wins.reduce((a, t) => a + t.pnl, 0);
	const grossLoss = Math.abs(losses.reduce((a, t) => a + t.pnl, 0));
	const profitFactor = grossLoss === 0 ? grossWin > 0 ? 99 : 0 : grossWin / grossLoss;
	const rets = equity.slice(1).map((e, i) => {
		const p = equity[i].v;
		return p ? (e.v - p) / p : 0;
	});
	const mean = rets.length ? rets.reduce((a, b) => a + b, 0) / rets.length : 0;
	const sd = rets.length ? Math.sqrt(rets.reduce((a, b) => a + (b - mean) ** 2, 0) / Math.max(1, rets.length - 1)) : 0;
	const sharpe = sd ? mean / sd * Math.sqrt(252) : 0;
	const neg = rets.filter((r) => r < 0);
	const dsd = neg.length ? Math.sqrt(neg.reduce((a, b) => a + b * b, 0) / neg.length) : 0;
	const sortino = dsd ? mean / dsd * Math.sqrt(252) : 0;
	let peak = start;
	let maxDd = 0;
	for (const e of equity) {
		peak = Math.max(peak, e.v);
		maxDd = Math.max(maxDd, peak ? (peak - e.v) / peak : 0);
	}
	const byMonth = /* @__PURE__ */ new Map();
	for (let i = 1; i < equity.length; i++) {
		const d = new Date(equity[i].t);
		const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
		const r = equity[i - 1].v ? (equity[i].v - equity[i - 1].v) / equity[i - 1].v : 0;
		byMonth.set(key, (byMonth.get(key) ?? 0) + r);
	}
	const byRegime = [
		"BULL_TREND",
		"BEAR_TREND",
		"RANGE",
		"HIGH_VOL",
		"LOW_VOL",
		"BREAKOUT",
		"MEAN_REVERT",
		"STRESS"
	].map((regime) => {
		const ts = trades.filter((t) => t.regime === regime);
		if (!ts.length) return null;
		return {
			regime,
			trades: ts.length,
			winRate: ts.filter((t) => t.pnl > 0).length / ts.length,
			pnl: ts.reduce((a, t) => a + t.pnl, 0)
		};
	}).filter((x) => x !== null);
	return {
		trades: trades.length,
		wins: wins.length,
		losses: losses.length,
		winRate: trades.length ? wins.length / trades.length : 0,
		lossRate: trades.length ? losses.length / trades.length : 0,
		totalReturn,
		cagr,
		netPnl,
		profitFactor,
		expectancy: trades.length ? netPnl / trades.length : 0,
		avgR: trades.length ? trades.reduce((a, t) => a + t.rMultiple, 0) / trades.length : 0,
		sharpe,
		sortino,
		maxDrawdown: maxDd,
		recoveryFactor: maxDd ? totalReturn / maxDd : 0,
		avgHoldBars: trades.length ? trades.reduce((a, t) => a + (t.exitTs - t.entryTs) / 864e5, 0) / trades.length : 0,
		bestTrade: trades.length ? Math.max(...trades.map((t) => t.pnl)) : 0,
		worstTrade: trades.length ? Math.min(...trades.map((t) => t.pnl)) : 0,
		costsTotal: trades.reduce((a, t) => a + t.costs, 0),
		monthly: [...byMonth.entries()].map(([month, ret]) => ({
			month,
			ret
		})),
		byRegime,
		equity
	};
}
function runWindow(bars, strategyId, cfg, product, symbol) {
	const def = STRATEGY_BY_ID[strategyId];
	const inst = getInstrument(symbol);
	let cash = STARTING_CASH;
	let qty = 0;
	let side = null;
	let entry = 0;
	let stop = 0;
	let target = 0;
	let entryTs = 0;
	let entryRegime = "RANGE";
	const trades = [];
	const equity = [];
	const riskFrac = .08;
	const closePos = (bar, px, reason) => {
		if (!qty || !side) return;
		const dir = side === "BUY" ? 1 : -1;
		const turnover = px * qty;
		const costs = estimateCosts({
			turnover: entry * qty,
			side,
			product,
			kind: inst.kind
		}).total + estimateCosts({
			turnover,
			side: side === "BUY" ? "SELL" : "BUY",
			product,
			kind: inst.kind
		}).total;
		const pnl = dir * (px - entry) * qty - costs;
		const risk = Math.abs(entry - stop) * qty || entry * .01 * qty;
		cash += dir === 1 ? qty * px : qty * (2 * entry - px);
		cash -= costs;
		trades.push({
			symbol,
			side,
			entryTs,
			exitTs: bar.t,
			entry,
			exit: px,
			qty,
			pnl,
			pnlPct: entry ? pnl / (entry * qty) : 0,
			rMultiple: risk ? pnl / risk : 0,
			costs,
			reason,
			regime: entryRegime
		});
		qty = 0;
		side = null;
	};
	for (let i = 40; i < bars.length; i++) {
		const window = bars.slice(0, i + 1);
		const bar = bars[i];
		const sig = def.run(window, {
			...def.defaults,
			...cfg
		});
		const regime = classifyRegime(window);
		if (qty && side) {
			if (side === "BUY" && (bar.l <= stop || bar.h >= target)) closePos(bar, bar.l <= stop ? stop : target, bar.l <= stop ? "stop" : "target");
			else if (side === "SELL" && (bar.h >= stop || bar.l <= target)) closePos(bar, bar.h >= stop ? stop : target, bar.h >= stop ? "stop" : "target");
			else if (sig.action === "SKIP" || side === "BUY" && sig.action === "SELL" || side === "SELL" && sig.action === "BUY") closePos(bar, bar.c, "signal flip");
		}
		if (!qty && (sig.action === "BUY" || sig.action === "SELL") && sig.entry && sig.stop) {
			const px = bar.c;
			const riskPer = Math.abs(px - sig.stop) || px * .01;
			const size = Math.max(1, Math.floor(cash * riskFrac / (riskPer || px)));
			const notional = size * px;
			if (notional > 0 && notional < cash * .95) {
				const costs = estimateCosts({
					turnover: notional,
					side: sig.action,
					product,
					kind: inst.kind
				}).total;
				cash -= costs;
				if (sig.action === "BUY") cash -= notional;
				else cash -= 0;
				qty = size;
				side = sig.action;
				entry = px;
				stop = sig.stop;
				target = sig.target ?? (sig.action === "BUY" ? px + (px - stop) * 2 : px - (stop - px) * 2);
				entryTs = bar.t;
				entryRegime = regime.label;
			}
		}
		const mtm = qty && side ? side === "BUY" ? qty * bar.c : qty * (2 * entry - bar.c) : 0;
		equity.push({
			t: bar.t,
			v: cash + mtm
		});
	}
	const last = bars[bars.length - 1];
	if (qty) closePos(last, last.c, "eod flatten");
	return {
		trades,
		equity
	};
}
function runBacktest(opts) {
	const timeframe = opts.timeframe ?? "1D";
	const product = opts.product ?? "INTRADAY";
	const cfg = opts.config ?? {};
	const def = STRATEGY_BY_ID[opts.strategyId];
	if (!def) throw new Error(opts.strategyId);
	const bars = barsOf(opts.symbol, timeframe);
	const { trades, equity } = runWindow(bars, opts.strategyId, cfg, product, opts.symbol);
	const from = bars[0].t;
	const to = bars[bars.length - 1].t;
	const m = metricsOf(trades, equity, from, to);
	const n = bars.length;
	const walkForward = [
		{
			train: [0, Math.floor(n * .5)],
			test: [Math.floor(n * .5), Math.floor(n * .7)]
		},
		{
			train: [0, Math.floor(n * .7)],
			test: [Math.floor(n * .7), Math.floor(n * .85)]
		},
		{
			train: [0, Math.floor(n * .85)],
			test: [Math.floor(n * .85), n]
		}
	].map((s, i) => {
		const testBars = bars.slice(s.test[0], s.test[1]);
		const r = runWindow(testBars, opts.strategyId, cfg, product, opts.symbol);
		const tm = metricsOf(r.trades, r.equity, testBars[0]?.t ?? from, testBars[testBars.length - 1]?.t ?? to);
		const fmt = (idx) => new Date(bars[Math.min(idx, bars.length - 1)].t).toISOString().slice(0, 10);
		return {
			window: `WF-${i + 1}`,
			train: `${fmt(s.train[0])} → ${fmt(s.train[1] - 1)}`,
			test: `${fmt(s.test[0])} → ${fmt(s.test[1] - 1)}`,
			testReturn: tm.totalReturn,
			testWinRate: tm.winRate,
			testSharpe: tm.sharpe
		};
	});
	const neighborKeys = Object.keys({
		...def.defaults,
		...cfg
	});
	const neighborRets = [];
	for (const key of neighborKeys.slice(0, 3)) {
		const base = {
			...def.defaults,
			...cfg
		};
		const step = def.params.find((p) => p.key === key)?.step ?? 1;
		for (const dir of [-1, 1]) {
			const c = {
				...base,
				[key]: (base[key] ?? 0) + dir * step
			};
			const r = runWindow(bars, opts.strategyId, c, product, opts.symbol);
			const tm = metricsOf(r.trades, r.equity, from, to);
			neighborRets.push(tm.totalReturn);
		}
	}
	const mean = neighborRets.reduce((a, b) => a + b, 0) / Math.max(1, neighborRets.length);
	const neighborStd = Math.sqrt(neighborRets.reduce((a, b) => a + (b - mean) ** 2, 0) / Math.max(1, neighborRets.length));
	const warning = neighborStd > .15 ? "Neighbor parameters swing hard — treat this as a fragile fit, not an edge." : m.maxDrawdown > .25 ? "Drawdown is large relative to return. Do not scale." : null;
	return {
		strategyId: opts.strategyId,
		version: def.version,
		symbol: opts.symbol,
		timeframe,
		from,
		to,
		config: {
			...def.defaults,
			...cfg
		},
		product,
		metrics: m,
		trades,
		walkForward,
		robust: {
			neighborStd,
			warning
		}
	};
}
function experimentGrid(opts) {
	if (!STRATEGY_BY_ID[opts.strategyId]) return [];
	const rsiVals = [
		50,
		55,
		60
	];
	const slVals = [
		.005,
		.01,
		.015
	];
	const rrVals = [
		1,
		2,
		3
	];
	const rows = [];
	const combos = [];
	if (opts.strategyId === "vwap_rsi") for (const rsiBuy of rsiVals) for (const slPct of slVals) for (const rr of rrVals) combos.push({
		rsiBuy,
		slPct,
		rr
	});
	else if (opts.strategyId === "ma_cross") for (const fast of [
		7,
		9,
		12
	]) for (const slPct of slVals) for (const rr of rrVals) combos.push({
		fast,
		slPct,
		rr
	});
	else for (const orBars of [
		2,
		3,
		4
	]) for (const slPct of slVals) for (const rr of rrVals) combos.push({
		orBars,
		slPct,
		rr
	});
	for (const config of combos) {
		const r = runBacktest({
			...opts,
			config
		});
		rows.push({
			label: Object.entries(config).map(([k, v]) => `${k}=${v}`).join(" · "),
			config,
			totalReturn: r.metrics.totalReturn,
			sharpe: r.metrics.sharpe,
			maxDrawdown: r.metrics.maxDrawdown,
			trades: r.metrics.trades,
			winRate: r.metrics.winRate
		});
	}
	rows.sort((a, b) => b.sharpe - a.sharpe);
	return rows;
}
function LabPage() {
	const search = Route$8.useSearch();
	const [symbol, setSymbol] = (0, import_react.useState)(search.symbol ?? "RELIANCE");
	const [strategyId, setStrategyId] = (0, import_react.useState)(search.strategy ?? "vwap_rsi");
	const result = useAura((s) => s.backtest);
	const busy = useAura((s) => s.backtestBusy);
	const setBacktest = useAura((s) => s.setBacktest);
	const setBusy = useAura((s) => s.setBacktestBusy);
	const [grid, setGrid] = (0, import_react.useState)([]);
	const def = STRATEGIES.find((s) => s.id === strategyId);
	const run = () => {
		setBusy(true);
		window.setTimeout(() => {
			const r = runBacktest({
				strategyId,
				symbol,
				product: "INTRADAY"
			});
			setBacktest(r);
			setBusy(false);
			toast.message("Backtest complete — read costs and walk-forward before calling it an edge.");
		}, 40);
	};
	const runGrid = () => {
		setBusy(true);
		window.setTimeout(() => {
			setGrid(experimentGrid({
				strategyId,
				symbol
			}));
			setBusy(false);
		}, 40);
	};
	const m = result?.metrics;
	const honest = m && (m.totalReturn <= 0 || m.maxDrawdown > .2 || (result.robust.warning ?? "").length > 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
					children: "Versioned strategies"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-medium tracking-tight",
					children: "Strategy lab"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted-foreground",
					children: "Indian cost model is on: brokerage cap, STT, stamp, exchange, GST, 2 bps slippage. A pretty in-sample curve is not permission to trade."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-3 p-4 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Strategy",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: sel,
							value: strategyId,
							onChange: (e) => setStrategyId(e.target.value),
							children: STRATEGIES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: s.id,
								children: [
									s.name,
									" ",
									s.version
								]
							}, s.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Symbol",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: sel,
							value: symbol,
							onChange: (e) => setSymbol(e.target.value),
							children: INSTRUMENTS.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: i.symbol,
								children: i.symbol
							}, i.symbol))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-end gap-2 md:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: run,
							disabled: busy,
							children: busy ? "Running…" : "Run backtest"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: runGrid,
							disabled: busy,
							children: "Parameter grid"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground md:col-span-4",
						children: def.summary
					})
				]
			}) }),
			m && result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				defaultValue: "metrics",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "metrics",
							children: "Metrics"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "walk",
							children: "Walk-forward"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "trades",
							children: "Trades"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "grid",
							children: "Grid"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "metrics",
						className: "mt-4 grid gap-4",
						children: [
							result.robust.warning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-xl bg-warn/10 px-4 py-3 text-sm text-warn",
								children: result.robust.warning
							}),
							honest && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl bg-secondary px-4 py-3 text-sm text-muted-foreground",
								children: [
									"This run is not labelled profitable. ",
									m.totalReturn <= 0 ? "Net return is non-positive after costs. " : "",
									m.maxDrawdown > .2 ? "Drawdown exceeds 20%. " : "",
									"Walk-forward and neighbor tests sit in the other tabs."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3 md:grid-cols-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Net P&L",
										v: formatInr(m.netPnl, true)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Total return",
										v: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, {
											value: m.totalReturn,
											pct: true
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "CAGR",
										v: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, {
											value: m.cagr,
											pct: true
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Sharpe",
										v: m.sharpe.toFixed(2)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Sortino",
										v: m.sortino.toFixed(2)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Max DD",
										v: formatPct(-m.maxDrawdown)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Win rate",
										v: formatPct(m.winRate, 1)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Profit factor",
										v: m.profitFactor.toFixed(2)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Expectancy",
										v: formatInr(m.expectancy, true)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Avg R",
										v: m.avgR.toFixed(2)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Trades",
										v: String(m.trades)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										k: "Costs",
										v: formatInr(m.costsTotal, true)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Equity (after costs)" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EquityChart, { data: m.equity }) })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "By regime" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
								className: "overflow-x-auto p-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "w-full text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "text-left text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-2 font-medium",
												children: "Regime"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-2 font-medium",
												children: "Trades"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-2 font-medium",
												children: "Win"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-4 py-2 font-medium",
												children: "P&L"
											})
										] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: m.byRegime.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t border-border",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-2",
												children: r.regime
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-2 font-mono tabular-nums",
												children: r.trades
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-2 font-mono tabular-nums",
												children: formatPct(r.winRate, 0)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-4 py-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, { value: r.pnl })
											})
										]
									}, r.regime)) })]
								})
							})] })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "walk",
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "overflow-x-auto p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "text-left text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Window"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Train"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Test"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Test ret"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Win"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Sharpe"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: result.walkForward.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2",
											children: w.window
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 text-muted-foreground",
											children: w.train
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 text-muted-foreground",
											children: w.test
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, {
												value: w.testReturn,
												pct: true
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 font-mono tabular-nums",
											children: formatPct(w.testWinRate, 0)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 font-mono tabular-nums",
											children: w.testSharpe.toFixed(2)
										})
									]
								}, w.window)) })]
							})
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted-foreground",
							children: [
								"Neighbor-parameter stdev ",
								(result.robust.neighborStd * 100).toFixed(1),
								"%. High dispersion means the fit is fragile."
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: "trades",
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
							className: "overflow-x-auto p-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[640px] text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "text-left text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Side"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Entry"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Exit"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "P&L"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "R"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Costs"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-4 py-2 font-medium",
											children: "Why"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: result.trades.slice(-40).reverse().map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2",
											children: t.side
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 font-mono tabular-nums",
											children: t.entry.toFixed(2)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 font-mono tabular-nums",
											children: t.exit.toFixed(2)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, { value: t.pnl })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 font-mono tabular-nums",
											children: t.rMultiple.toFixed(2)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 font-mono tabular-nums",
											children: t.costs.toFixed(0)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-2 text-muted-foreground",
											children: t.reason
										})
									]
								}, i)) })]
							})
						}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "grid",
						className: "mt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-3 text-sm text-muted-foreground",
								children: "Ranked by Sharpe, not raw profit. The top row is not \"the best strategy\" — check drawdown and neighbor stability."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: runGrid,
								className: "mb-3",
								children: grid.length ? "Re-run grid" : "Run 27 combinations"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GridTable, { rows: grid })
						]
					})
				]
			})
		]
	});
}
var sel = "h-10 w-full rounded-md bg-secondary px-3 text-sm shadow-[var(--shadow-border)]";
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
			children: label
		}), children]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-3 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-mono text-lg tabular-nums",
			children: v
		})]
	});
}
function GridTable({ rows }) {
	const shown = (0, import_react.useMemo)(() => rows.slice(0, 12), [rows]);
	if (!shown.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Run the grid to rank parameter sets."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
		className: "overflow-x-auto p-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-left text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-2 font-medium",
						children: "Params"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-2 font-medium",
						children: "Return"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-2 font-medium",
						children: "Sharpe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-2 font-medium",
						children: "DD"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-2 font-medium",
						children: "Win"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-2 font-medium",
						children: "N"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2 text-xs",
						children: r.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, {
							value: r.totalReturn,
							pct: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2 font-mono tabular-nums",
						children: r.sharpe.toFixed(2)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2 font-mono tabular-nums",
						children: formatPct(-r.maxDrawdown)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2 font-mono tabular-nums",
						children: formatPct(r.winRate, 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2 font-mono tabular-nums",
						children: r.trades
					})
				]
			}, r.label)) })]
		})
	}) });
}
//#endregion
export { LabPage as component };
