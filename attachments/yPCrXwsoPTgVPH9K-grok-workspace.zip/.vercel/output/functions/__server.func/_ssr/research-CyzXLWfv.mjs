import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as getInstrument, D as formatPct, F as useAura, S as computeIndicators, i as ActionChip, n as Route$2, p as REGIME_LABEL, y as barsOf } from "./router-RvxJo3IS.mjs";
import { t as Button } from "./button-tfFoUuRd.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-CI6nIXAM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/research-CyzXLWfv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var reviewSetup = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("db588161a041c3e6dd46c67fc844d59773dd5685f85b285b32546230cae5471f"));
function ResearchPage() {
	const search = Route$2.useSearch();
	const signals = useAura((s) => s.signals);
	const [symbol, setSymbol] = (0, import_react.useState)(search.symbol ?? signals[0]?.symbol ?? "NIFTY");
	const [note, setNote] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)(null);
	const d = signals.find((x) => x.symbol === symbol) ?? signals[0];
	const run = async () => {
		if (!d) return;
		setBusy(true);
		setErr(null);
		const inst = getInstrument(d.symbol);
		const ind = computeIndicators(barsOf(d.symbol, "1D"));
		const res = await reviewSetup({ data: {
			symbol: d.symbol,
			name: inst.name,
			action: d.action,
			confidence: d.confidence,
			regime: d.regime.label,
			regimeNotes: d.regime.notes,
			strategy: `${d.strategy.strategyId}@${d.strategy.version}`,
			strategyReason: d.strategy.reason,
			invalidation: d.invalidation,
			similar: d.similar.n ? `n=${d.similar.n}, win ${formatPct(d.similar.winRate, 0)}, avg ${formatPct(d.similar.avgReturn)}` : "insufficient sample",
			evidence: d.reasons.map((e) => e.text),
			contradictions: d.contradictions.map((e) => e.text),
			risk: d.risk,
			indicators: `RSI ${ind.rsi.toFixed(1)}, ADX ${ind.adx.toFixed(1)}, VWAP ${ind.vwap.toFixed(2)}, RV ${(ind.realizedVol * 100).toFixed(1)}%, relVol ${ind.relVolume.toFixed(2)}`,
			lineage: `${d.lineage.strategyVersion} / ${d.lineage.modelVersion} / ${d.lineage.datasetVersion}`
		} });
		setBusy(false);
		if (!res.ok) {
			setErr(res.error);
			toast.error(res.error);
			return;
		}
		setNote(res.text);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-3xl gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
					children: "Explainer, not a signal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-medium tracking-tight",
					children: "Research desk"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "The model is handed numbers this desk already computed. It may not invent prices, edges, or orders. User initiated — never on page load."
				})
			] }),
			d && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-8 rounded-md bg-secondary px-2 text-sm",
						value: d.symbol,
						onChange: (e) => setSymbol(e.target.value),
						children: signals.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s.symbol,
							children: s.symbol
						}, s.symbol))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionChip, { action: d.action }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm font-normal text-muted-foreground",
						children: [
							REGIME_LABEL[d.regime.label],
							" · ",
							(d.confidence * 100).toFixed(0),
							"%"
						]
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: d.strategy.reason
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-1 text-sm text-muted-foreground",
						children: d.contradictions.slice(0, 3).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["— ", c.text] }, c.text))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: run,
						disabled: busy,
						children: busy ? "Reading the file…" : "Ask the research desk"
					})
				]
			})] }),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-down",
				children: err
			}),
			note && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Note" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "whitespace-pre-wrap text-sm leading-relaxed",
				children: note
			}) })] })
		]
	});
}
//#endregion
export { ResearchPage as component };
