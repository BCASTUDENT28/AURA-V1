import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { F as useAura, N as sectorReturn, T as formatInrCompact, a as Price, b as classifyRegime, d as INSTRUMENTS, i as ActionChip, j as getUniverse, k as formatVolume, m as SECTORS, o as Signed, p as REGIME_LABEL, y as barsOf } from "./router-RvxJo3IS.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-CI6nIXAM.mjs";
import { n as SignalDetail, r as Sparkline, t as CandleChart } from "./signal-detail-CWR74-1b.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ee5w9rFx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Overview() {
	const quotes = useAura((s) => s.quotes);
	const signals = useAura((s) => s.signals);
	const book = useAura((s) => s.book);
	const nav = useAura((s) => s.nav());
	const risk = useAura((s) => s.riskSnap);
	const selected = useAura((s) => s.selectedSymbol);
	const setSymbol = useAura((s) => s.setSymbol);
	const [open, setOpen] = (0, import_react.useState)(null);
	const niftyBars = barsOf("NIFTY", "1D");
	const regime = classifyRegime(niftyBars);
	const quality = getUniverse().quality;
	const actionable = signals.filter((d) => d.action === "BUY" || d.action === "SELL").slice(0, 8);
	const sectors = (0, import_react.useMemo)(() => SECTORS.filter((s) => s !== "Index").map((s) => ({
		s,
		r: sectorReturn(quotes, s)
	})).sort((a, b) => b.r - a.r), [quotes]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
						children: "Intelligence OS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-medium tracking-tight md:text-3xl",
						children: "Indian cash desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-xl text-sm text-muted-foreground",
						children: "Probabilities, evidence, and a risk veto. Not a forecast. Live trading is disabled."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right text-[11px] text-muted-foreground",
					children: [
						"Data ",
						quality.status,
						" · ",
						quality.timezone,
						" · CA-adjusted · ",
						quality.datasetVersion
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexCard, { symbol: "NIFTY" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndexCard, { symbol: "BANKNIFTY" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Market regime" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-lg font-medium",
							children: REGIME_LABEL[regime.label]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-muted-foreground",
							children: regime.notes
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-3 font-mono text-xs tabular-nums text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["ADX ", regime.adx.toFixed(1)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"RV ",
								(regime.realizedVol * 100).toFixed(1),
								"%"
							] })]
						})
					] })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Paper book" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-2xl tabular-nums",
							children: formatInrCompact(nav)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 text-sm",
							children: ["Day P&L ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, {
								value: book.dailyPnl / 1e6,
								pct: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-2 gap-2 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Positions ", book.positions.length] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"Exposure ",
									(risk.exposurePct * 100).toFixed(0),
									"%"
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: risk.canTrade ? "text-up" : "text-down",
									children: risk.canTrade ? "Risk clear" : "Risk blocked"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: risk.killSwitch ? "Kill on" : "Kill off" })
							]
						})
					] })] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[1.4fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, { children: [selected, " · daily"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "h-8 rounded-md bg-secondary px-2 text-xs shadow-[var(--shadow-border)]",
					value: selected,
					onChange: (e) => setSymbol(e.target.value),
					children: INSTRUMENTS.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: i.symbol,
						children: i.symbol
					}, i.symbol))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "h-56",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CandleChart, { bars: barsOf(selected, "1D") })
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Sector tape" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "grid gap-1.5",
					children: sectors.map(({ s, r }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-20 text-xs text-muted-foreground",
								children: s
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-1.5 flex-1 overflow-hidden rounded-full bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full ${r >= 0 ? "bg-up" : "bg-down"}`,
									style: { width: `${Math.min(100, Math.abs(r) * 1400)}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-14 text-right font-mono text-xs tabular-nums",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, {
									value: r,
									pct: true
								})
							})
						]
					}, s))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Active signals" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/signals",
				className: "text-xs text-muted-foreground hover:text-foreground",
				children: "Full board"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2 font-medium",
								children: "Symbol"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2 font-medium",
								children: "Action"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2 font-medium",
								children: "Conf"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2 font-medium",
								children: "Regime"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2 font-medium",
								children: "R:R"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-2 font-medium",
								children: "Why"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: actionable.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "cursor-pointer border-t border-border hover:bg-accent/40",
						onClick: () => setOpen(d),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2.5 font-medium",
								children: d.symbol
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionChip, { action: d.action })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-2.5 font-mono tabular-nums",
								children: [(d.confidence * 100).toFixed(0), "%"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2.5 text-muted-foreground",
								children: REGIME_LABEL[d.regime.label]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-2.5 font-mono tabular-nums",
								children: d.expectedRR?.toFixed(1) ?? "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "max-w-xs truncate px-4 py-2.5 text-muted-foreground",
								children: d.strategy.reason
							})
						]
					}, d.id)) })]
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalDetail, {
				d: open,
				open: !!open,
				onOpenChange: (v) => !v && setOpen(null)
			})
		]
	});
}
function IndexCard({ symbol }) {
	const q = useAura((s) => s.quotes[symbol]);
	const bars = barsOf(symbol, "1D");
	if (!q) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
		className: "p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-[0.14em] text-muted-foreground",
					children: symbol
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 font-mono text-2xl tabular-nums",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Price, { value: q.ltp })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-1 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, {
						value: q.changePct,
						pct: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-2 text-muted-foreground",
						children: ["Vol ", formatVolume(q.volume)]
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkline, {
				bars,
				className: "h-10 w-24"
			})]
		})
	}) });
}
//#endregion
export { Overview as component };
