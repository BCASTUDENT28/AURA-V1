import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { A as getInstrument, D as formatPct, F as useAura, M as navOf, P as unrealizedOf, o as Signed, w as formatInr } from "./router-RvxJo3IS.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-CI6nIXAM.mjs";
import { c as ResponsiveContainer, l as Tooltip, n as PieChart, o as Pie, s as Cell } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/portfolio-48IVAVRe.js
var import_jsx_runtime = require_jsx_runtime();
var COLORS = [
	"#c5ccd6",
	"#5dba87",
	"#8b8e96",
	"#d4676f",
	"#9aa8bc",
	"#c4a35a",
	"#6e7a88"
];
function PortfolioPage() {
	const book = useAura((s) => s.book);
	const quotes = useAura((s) => s.quotes);
	const nav = navOf(book, quotes);
	const u = unrealizedOf(book, quotes);
	const risk = useAura((s) => s.riskSnap);
	const holdings = book.positions.map((p) => {
		const ltp = quotes[p.symbol]?.ltp ?? p.avgPrice;
		const value = Math.abs(p.qty * ltp);
		const pnl = (p.side === "BUY" ? 1 : -1) * (ltp - p.avgPrice) * p.qty;
		return {
			...p,
			ltp,
			value,
			pnl,
			sector: getInstrument(p.symbol).sector
		};
	});
	const bySector = /* @__PURE__ */ new Map();
	for (const h of holdings) bySector.set(h.sector, (bySector.get(h.sector) ?? 0) + h.value);
	const pie = [{
		name: "Cash",
		value: Math.max(0, book.cash)
	}, ...[...bySector.entries()].map(([name, value]) => ({
		name,
		value
	}))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
					children: "Book"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-medium tracking-tight",
					children: "Portfolio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted-foreground",
					children: "A trade is only interesting if the rest of the book can absorb it. Concentration and correlation sit above any single signal."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "NAV",
						v: formatInr(nav)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Cash",
						v: formatInr(book.cash)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Unrealized",
						v: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, { value: u })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						k: "Exposure",
						v: formatPct(risk.exposurePct, 1)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Allocation" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "h-64",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
							data: pie,
							dataKey: "value",
							nameKey: "name",
							innerRadius: 58,
							outerRadius: 88,
							paddingAngle: 2,
							children: pie.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: COLORS[i % COLORS.length] }, e.name))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
							contentStyle: {
								background: "#14171d",
								border: "1px solid #23262e",
								borderRadius: 8,
								fontSize: 12
							},
							formatter: (v, n) => [formatInr(v), n]
						})] })
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Holdings" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "overflow-x-auto p-0",
					children: holdings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "p-4 text-sm text-muted-foreground",
						children: "Cash only. Open a paper position from Signals or Paper."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "text-left text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2 font-medium",
									children: "Symbol"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2 font-medium",
									children: "Sector"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2 font-medium",
									children: "Value"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2 font-medium",
									children: "Weight"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-2 font-medium",
									children: "P&L"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: holdings.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2",
									children: h.symbol
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2 text-muted-foreground",
									children: h.sector
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2 font-mono tabular-nums",
									children: formatInr(h.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2 font-mono tabular-nums",
									children: formatPct(h.value / nav, 1)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Signed, { value: h.pnl })
								})
							]
						}, h.symbol)) })]
					})
				})] })]
			})
		]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-mono text-xl tabular-nums",
			children: v
		})]
	});
}
//#endregion
export { PortfolioPage as component };
