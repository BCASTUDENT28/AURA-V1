import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-BixeQywY.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var reviewSetup_createServerFn_handler = createServerRpc({
	id: "db588161a041c3e6dd46c67fc844d59773dd5685f85b285b32546230cae5471f",
	name: "reviewSetup",
	filename: "src/lib/aura/ai.ts"
}, (opts) => reviewSetup.__executeServer(opts));
var reviewSetup = createServerFn({ method: "POST" }).validator((input) => input).handler(reviewSetup_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI research is unavailable in this environment."
	};
	const system = `You are AURA's research analyst for Indian cash equities. You do not place orders. You do not predict the future. You do not invent numbers.

Rules:
- Use ONLY the computed evidence provided. If a figure is missing, say so.
- Separate signal, probability, confidence, risk, historical evidence, and uncertainty.
- Never claim a strategy is profitable unless the provided metrics say so.
- Never guarantee returns. Never say "100%" or "sure shot".
- If contradictions exist, lead with them.
- Cite the strategy version and dataset version when you refer to the signal.
- End with: what would invalidate the view, and what a risk manager would refuse.
- Keep it under 280 words. Plain professional English. No emoji. No hype.`;
	const user = `Symbol: ${data.symbol} (${data.name})
Action from decision engine: ${data.action}
Confidence: ${(data.confidence * 100).toFixed(0)}%
Risk tag: ${data.risk}
Regime: ${data.regime} — ${data.regimeNotes}
Strategy: ${data.strategy}
Strategy reason: ${data.strategyReason}
Invalidation: ${data.invalidation}
Similarity: ${data.similar}
Evidence:
- ${data.evidence.join("\n- ")}
Contradictions:
- ${data.contradictions.join("\n- ")}
Indicators: ${data.indicators}
Lineage: ${data.lineage}

Write a research note. Do not recommend live trading. This is a paper environment with simulated data.`;
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 700,
			temperature: .3,
			messages: [{
				role: "system",
				content: system
			}, {
				role: "user",
				content: user
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `Research desk unavailable (${res.status}).`
	};
	return {
		ok: true,
		text: (await res.json()).choices[0]?.message.content ?? ""
	};
});
//#endregion
export { reviewSetup_createServerFn_handler };
