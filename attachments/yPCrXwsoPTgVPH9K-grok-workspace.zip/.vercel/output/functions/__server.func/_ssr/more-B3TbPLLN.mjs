import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Shield, d as BookOpen, i as Sparkles, s as Newspaper } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-B3TbPLLN.js
var import_jsx_runtime = require_jsx_runtime();
var ITEMS = [
	{
		to: "/risk",
		label: "Risk engine",
		copy: "Hard gates, kill switch, 9 OPS, limit-only.",
		icon: Shield
	},
	{
		to: "/memory",
		label: "Memory",
		copy: "Learnings from paper outcomes only.",
		icon: BookOpen
	},
	{
		to: "/news",
		label: "News",
		copy: "Headline sentiment. Does not trade.",
		icon: Newspaper
	},
	{
		to: "/research",
		label: "Research desk",
		copy: "LLM explainer over computed evidence.",
		icon: Sparkles
	}
];
function MorePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-lg gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-medium tracking-tight",
			children: "Desk"
		}), ITEMS.map((it) => {
			const Icon = it.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: it.to,
				className: "flex min-h-16 items-center gap-3 rounded-xl bg-card px-4 py-3 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-sm font-medium",
					children: it.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted-foreground",
					children: it.copy
				})] })]
			}, it.to);
		})]
	});
}
//#endregion
export { MorePage as component };
