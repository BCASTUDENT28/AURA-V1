import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { D as formatPct, F as useAura, s as Switch, u as DEFAULT_LIMITS, w as formatInr } from "./router-RvxJo3IS.mjs";
import { t as Button } from "./button-tfFoUuRd.mjs";
import { i as CardTitle, n as CardContent, r as CardHeader, t as Card } from "./card-CI6nIXAM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/risk-BB_Wf0kf.js
var import_jsx_runtime = require_jsx_runtime();
function RiskPage() {
	const risk = useAura((s) => s.riskSnap);
	const kill = useAura((s) => s.killSwitch);
	const setKill = useAura((s) => s.setKill);
	const flatten = useAura((s) => s.flatten);
	const rows = [
		{
			k: "Environment",
			v: "PAPER",
			ok: true,
			note: "Live credentials are not loaded. Live path is sealed."
		},
		{
			k: "Kill switch",
			v: kill ? "ARMED" : "off",
			ok: !kill,
			note: "Overrides every signal. AI cannot disarm it."
		},
		{
			k: "Daily loss",
			v: formatPct(risk.dailyPnlPct),
			ok: risk.dailyPnlPct > -DEFAULT_LIMITS.maxDailyLossPct,
			note: `Breaker at −${(DEFAULT_LIMITS.maxDailyLossPct * 100).toFixed(0)}%.`
		},
		{
			k: "Exposure",
			v: formatPct(risk.exposurePct, 1),
			ok: risk.exposurePct <= DEFAULT_LIMITS.maxExposurePct,
			note: `Cap ${(DEFAULT_LIMITS.maxExposurePct * 100).toFixed(0)}% of NAV.`
		},
		{
			k: "Open positions",
			v: String(risk.openPositions),
			ok: risk.openPositions < DEFAULT_LIMITS.maxPositions,
			note: `Max ${DEFAULT_LIMITS.maxPositions}.`
		},
		{
			k: "Order type",
			v: "LIMIT only",
			ok: true,
			note: "NSE: algo orders cannot be Market or IOC."
		},
		{
			k: "OPS throttle",
			v: `${DEFAULT_LIMITS.opsPerSec}/sec`,
			ok: true,
			note: "Angel One enforces 9/sec, one under the NSE 10 OPS line."
		},
		{
			k: "Data freshness",
			v: `${Math.round(risk.dataAgeMs)} ms`,
			ok: risk.dataAgeMs <= DEFAULT_LIMITS.dataFreshMs,
			note: "Stale tape cannot become a signal."
		},
		{
			k: "Static IP",
			v: risk.staticIpOk ? "verified (paper)" : "missing",
			ok: risk.staticIpOk,
			note: "Required before any live API session."
		},
		{
			k: "Stop-loss",
			v: "required",
			ok: true,
			note: "Ticket without a stop is rejected."
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
						children: "Hard gates"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-2xl font-medium tracking-tight",
						children: "Risk engine"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-2xl text-sm text-muted-foreground",
						children: "If risk fails, the final decision is SKIP. No model, committee, or prompt can override that without a system-level change — which this desk will not do."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex h-10 items-center gap-2 text-sm",
						children: ["Kill switch", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: kill,
							onCheckedChange: setKill
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: flatten,
						children: "Flatten book"
					})]
				})]
			}),
			!risk.canTrade && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-destructive/10 px-4 py-3 text-sm text-destructive",
				children: ["Trading blocked. ", risk.breaches.join(" ")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
					className: "flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.k }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `text-xs font-medium ${r.ok ? "text-up" : "text-down"}`,
						children: r.ok ? "PASS" : "FAIL"
					})]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-lg tabular-nums",
					children: r.v
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: r.note
				})] })] }, r.k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Day P&L vs breaker" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-mono text-2xl tabular-nums",
					children: formatInr(risk.dailyPnl, true)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-2 overflow-hidden rounded-full bg-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `h-full ${risk.dailyPnl >= 0 ? "bg-up" : "bg-down"}`,
						style: { width: `${Math.min(100, Math.abs(risk.dailyPnlPct) / DEFAULT_LIMITS.maxDailyLossPct * 100)}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted-foreground",
					children: "Bar fills as you approach the −2% daily loss circuit."
				})
			] })] })
		]
	});
}
//#endregion
export { RiskPage as component };
