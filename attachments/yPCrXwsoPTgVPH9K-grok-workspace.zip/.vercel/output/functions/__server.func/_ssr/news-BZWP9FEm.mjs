import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { E as formatIst, F as useAura, f as NEWS_DISCLAIMER } from "./router-RvxJo3IS.mjs";
import { n as CardContent, t as Card } from "./card-CI6nIXAM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/news-BZWP9FEm.js
var import_jsx_runtime = require_jsx_runtime();
function NewsPage() {
	const news = useAura((s) => s.news);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
				children: "Context"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-medium tracking-tight",
				children: "News & sentiment"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-muted-foreground",
				children: NEWS_DISCLAIMER
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3",
			children: news.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex flex-col gap-2 p-4 md:flex-row md:items-start md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
							children: [
								n.source,
								" · ",
								n.event,
								" · ",
								n.impact
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-base font-medium tracking-tight",
							children: n.headline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 flex flex-wrap gap-1.5",
							children: n.symbols.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-secondary px-2 py-0.5 text-[11px] text-muted-foreground",
								children: s
							}, s))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "shrink-0 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `font-mono text-sm tabular-nums ${n.sentiment > .05 ? "text-up" : n.sentiment < -.05 ? "text-down" : "text-muted-foreground"}`,
						children: [n.sentiment > 0 ? "+" : "", n.sentiment.toFixed(2)]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] text-muted-foreground",
						children: formatIst(n.ts)
					})]
				})]
			}) }, n.id))
		})]
	});
}
//#endregion
export { NewsPage as component };
