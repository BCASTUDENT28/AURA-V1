import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, i as DialogDescription$1, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { A as getInstrument, D as formatPct, S as computeIndicators, _ as STRATEGY_BY_ID, a as Price, c as Badge, i as ActionChip, l as ACTION_LABEL, p as REGIME_LABEL, x as cn, y as barsOf } from "./router-RvxJo3IS.mjs";
import { t as Button } from "./button-tfFoUuRd.mjs";
import { n as OrderTicket } from "./order-ticket-DNpA_bLK.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/signal-detail-CWR74-1b.js
var import_jsx_runtime = require_jsx_runtime();
function CandleChart({ bars, className, count = 72 }) {
	const slice = bars.slice(-count);
	if (slice.length < 2) return null;
	const w = 640;
	const h = 220;
	const pad = {
		t: 12,
		r: 12,
		b: 18,
		l: 8
	};
	const highs = slice.map((b) => b.h);
	const lows = slice.map((b) => b.l);
	const min = Math.min(...lows);
	const max = Math.max(...highs);
	const span = max - min || 1;
	const cw = (w - pad.l - pad.r) / slice.length;
	const y = (px) => pad.t + (max - px) / span * (h - pad.t - pad.b);
	const last = slice[slice.length - 1];
	const first = slice[0];
	const up = last.c >= first.o;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: cn("h-full w-full", className),
		role: "img",
		"aria-label": "Price chart",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: pad.l,
				x2: w - pad.r,
				y1: y(last.c),
				y2: y(last.c),
				stroke: "currentColor",
				strokeOpacity: .12,
				strokeDasharray: "3 4"
			}),
			slice.map((b, i) => {
				const x = pad.l + i * cw + cw / 2;
				const color = b.c >= b.o ? "#5dba87" : "#d4676f";
				const bodyTop = y(Math.max(b.o, b.c));
				const bodyBot = y(Math.min(b.o, b.c));
				const bh = Math.max(1.2, bodyBot - bodyTop);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
					x1: x,
					x2: x,
					y1: y(b.h),
					y2: y(b.l),
					stroke: color,
					strokeWidth: 1
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: x - Math.max(1.4, cw * .32),
					y: bodyTop,
					width: Math.max(2.8, cw * .64),
					height: bh,
					fill: color
				})] }, b.t);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
				x: w - pad.r,
				y: y(last.c) - 4,
				textAnchor: "end",
				fill: up ? "#5dba87" : "#d4676f",
				fontSize: "11",
				fontFamily: "IBM Plex Mono, ui-monospace, monospace",
				children: last.c.toFixed(2)
			})
		]
	});
}
function Sparkline({ bars, className }) {
	const slice = bars.slice(-40);
	if (slice.length < 2) return null;
	const w = 120;
	const h = 36;
	const min = Math.min(...slice.map((b) => b.l));
	const max = Math.max(...slice.map((b) => b.h));
	const span = max - min || 1;
	const d = slice.map((b, i) => {
		const x = i / (slice.length - 1) * w;
		const y = (max - b.c) / span * 32 + 2;
		return `${i === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
	}).join(" ");
	const up = slice[slice.length - 1].c >= slice[0].c;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: cn("overflow-visible", className),
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d,
			fill: "none",
			stroke: up ? "#5dba87" : "#d4676f",
			strokeWidth: "1.5"
		})
	});
}
var Dialog = Dialog$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-background/70 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(720px,calc(100vw-1.5rem))] max-h-[min(88dvh,860px)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-2xl bg-card p-5 shadow-[var(--shadow-border)] outline-none", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			className: "absolute top-3 right-3 flex size-10 items-center justify-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-base font-medium tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function Separator({ className, orientation = "horizontal", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "separator",
		className: cn("bg-border", orientation === "horizontal" ? "h-px w-full" : "h-full w-px", className),
		...props
	});
}
function SignalDetail({ d, open, onOpenChange }) {
	if (!d) return null;
	const inst = getInstrument(d.symbol);
	const bars = barsOf(d.symbol, "1D");
	const ind = computeIndicators(bars);
	const strat = STRATEGY_BY_ID[d.strategy.strategyId];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, {
				className: "pr-8",
				children: [inst.symbol, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "ml-2 text-sm font-normal text-muted-foreground",
					children: inst.name
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Signal is not a decision. Decision is not certainty. Risk can still veto." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionChip, { action: d.action }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						children: REGIME_LABEL[d.regime.label]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						children: [
							"Conf ",
							(d.confidence * 100).toFixed(0),
							"%"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						children: d.risk
					}),
					d.expectedRR != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						variant: "outline",
						children: ["R:R ", d.expectedRR.toFixed(1)]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 h-40 overflow-hidden rounded-lg bg-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CandleChart, { bars })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-3 gap-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prob, {
						label: "Up",
						v: d.probabilityUp,
						tone: "text-up"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prob, {
						label: "Neutral",
						v: d.probabilityNeutral
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prob, {
						label: "Down",
						v: d.probabilityDown,
						tone: "text-down"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Strategy",
						v: `${strat?.name ?? d.strategy.strategyId} ${d.strategy.version}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Entry",
						v: d.entry ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Price, { value: d.entry }) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Stop",
						v: d.stop ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Price, { value: d.stop }) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Target",
						v: d.target ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Price, { value: d.target }) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Invalidation",
						v: d.invalidation
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						k: "Similarity",
						v: d.similar.n ? `${d.similar.n} matches · win ${formatPct(d.similar.winRate, 0)} · avg ${formatPct(d.similar.avgReturn)} · MAE ${formatPct(d.similar.avgMae)}` : "Insufficient neighbors"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
					title: "Evidence",
					items: d.reasons.map((e) => e.text),
					tone: "up"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
					title: "Contradictions",
					items: d.contradictions.map((e) => e.text),
					tone: "down"
				})]
			}),
			d.riskReasons.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-lg bg-destructive/10 p-3 text-sm text-destructive",
				children: ["Risk veto: ", d.riskReasons.join(" ")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-mono text-[10px] text-muted-foreground",
				children: [
					d.lineage.strategyVersion,
					" · ",
					d.lineage.modelVersion,
					" · ",
					d.lineage.featureVersion,
					" · ",
					d.lineage.datasetVersion
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-[11px] text-muted-foreground",
				children: [
					"RSI ",
					ind.rsi.toFixed(0),
					" · ADX ",
					ind.adx.toFixed(1),
					" · VWAP ",
					ind.vwap.toFixed(2),
					" · RV ",
					(ind.realizedVol * 100).toFixed(1),
					"%"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-4" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderTicket, {
					symbol: d.symbol,
					side: d.action === "SELL" ? "SELL" : "BUY",
					suggested: d.entry ?? void 0,
					stop: d.stop,
					target: d.target,
					strategyId: d.strategy.strategyId
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/research",
								search: { symbol: d.symbol },
								children: "Open research desk"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/lab",
								search: {
									symbol: d.symbol,
									strategy: d.strategy.strategyId
								},
								children: "Backtest this strategy"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] text-muted-foreground",
							children: [ACTION_LABEL[d.action], " is a paper suggestion. Live path is sealed."]
						})
					]
				})]
			})
		] })
	});
}
function Prob({ label, v, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-muted px-2 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] uppercase tracking-[0.14em] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: `mt-1 font-mono text-lg tabular-nums ${tone ?? ""}`,
			children: [(v * 100).toFixed(0), "%"]
		})]
	});
}
function Row({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[110px_1fr] gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm",
			children: v
		})]
	});
}
function List({ title, items, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 grid gap-1.5",
		children: items.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex gap-2 text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: tone === "up" ? "text-up" : "text-down",
				children: "—"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t })]
		}, t))
	})] });
}
//#endregion
export { SignalDetail as n, Sparkline as r, CandleChart as t };
