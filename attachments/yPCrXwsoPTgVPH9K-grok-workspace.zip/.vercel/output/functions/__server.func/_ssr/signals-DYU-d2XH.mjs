import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { A as getInstrument, F as useAura, a as Price, i as ActionChip, p as REGIME_LABEL } from "./router-RvxJo3IS.mjs";
import { n as CardContent, t as Card } from "./card-CI6nIXAM.mjs";
import { t as Input } from "./order-ticket-DNpA_bLK.mjs";
import { n as SignalDetail } from "./signal-detail-CWR74-1b.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/signals-DYU-d2XH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	"ALL",
	"BUY",
	"SELL",
	"HOLD",
	"SKIP"
];
function SignalsPage() {
	const signals = useAura((s) => s.signals);
	const quotes = useAura((s) => s.quotes);
	const [q, setQ] = (0, import_react.useState)("");
	const [f, setF] = (0, import_react.useState)("ALL");
	const [open, setOpen] = (0, import_react.useState)(null);
	const rows = (0, import_react.useMemo)(() => signals.filter((d) => {
		if (f !== "ALL" && d.action !== f) return false;
		const inst = getInstrument(d.symbol);
		return `${d.symbol} ${inst.name} ${inst.sector}`.toLowerCase().includes(q.toLowerCase());
	}), [
		signals,
		q,
		f
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-7xl gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
					children: "Decision board"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-medium tracking-tight",
					children: "Signals"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-sm text-muted-foreground",
					children: "Each row is a versioned strategy output, a regime, a similarity sample, and a risk tag. Click through for evidence and contradictions. Nothing here is a live order."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Filter symbol or sector",
					className: "max-w-xs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1",
					children: FILTERS.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setF(x),
						className: `h-10 rounded-md px-3 text-xs ${f === x ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`,
						children: x
					}, x))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "overflow-x-auto p-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[720px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-left text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Symbol"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "LTP"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Action"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Conf"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "P(up)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Risk"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Strategy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Regime"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Similar"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((d) => {
						const inst = getInstrument(d.symbol);
						const px = quotes[d.symbol];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "cursor-pointer border-t border-border hover:bg-accent/40",
							onClick: () => setOpen(d),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-2.5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-medium",
										children: d.symbol
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground",
										children: inst.sector
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2.5 font-mono tabular-nums",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Price, { value: px?.ltp ?? 0 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionChip, { action: d.action })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-2.5 font-mono tabular-nums",
									children: [(d.confidence * 100).toFixed(0), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-2.5 font-mono tabular-nums",
									children: [(d.probabilityUp * 100).toFixed(0), "%"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2.5 text-xs",
									children: d.risk
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-2.5 text-muted-foreground",
									children: [
										d.strategy.strategyId,
										"@ ",
										d.strategy.version
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-2.5 text-muted-foreground",
									children: REGIME_LABEL[d.regime.label]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-2.5 font-mono text-xs tabular-nums",
									children: [
										"n=",
										d.similar.n,
										" · ",
										(d.similar.winRate * 100).toFixed(0),
										"%"
									]
								})
							]
						}, d.id);
					}) })]
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignalDetail, {
				d: open,
				open: !!open,
				onOpenChange: (v) => !v && setOpen(null)
			})
		]
	});
}
//#endregion
export { SignalsPage as component };
