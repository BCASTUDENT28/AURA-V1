import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as getInstrument, F as useAura, O as formatPrice, x as cn } from "./router-RvxJo3IS.mjs";
import { t as Button } from "./button-tfFoUuRd.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/order-ticket-DNpA_bLK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-10 w-full rounded-md bg-secondary px-3 text-sm text-foreground outline-none shadow-[var(--shadow-border)] placeholder:text-muted-foreground/70 focus-visible:ring-2 focus-visible:ring-ring/40", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground", className),
		...props
	});
}
function OrderTicket({ symbol, side, suggested, stop, target, strategyId }) {
	const quote = useAura((s) => s.quotes[symbol]);
	const place = useAura((s) => s.place);
	const [qty, setQty] = (0, import_react.useState)("10");
	const [limit, setLimit] = (0, import_react.useState)("");
	const [stopPx, setStopPx] = (0, import_react.useState)(stop ? String(stop.toFixed(2)) : "");
	const [tgt, setTgt] = (0, import_react.useState)(target ? String(target.toFixed(2)) : "");
	const [act, setAct] = (0, import_react.useState)(side ?? "BUY");
	const inst = getInstrument(symbol);
	const px = suggested ?? quote?.ltp ?? inst.base;
	const limitPx = Number(limit || px);
	const submit = () => {
		const q = Math.floor(Number(qty));
		const res = place({
			symbol,
			side: act,
			qty: q,
			limitPrice: limitPx,
			stop: stopPx ? Number(stopPx) : null,
			target: tgt ? Number(tgt) : null,
			strategyId: strategyId ?? null
		});
		if (res.ok) toast.success(res.message);
		else toast.error(res.message);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1 rounded-lg bg-secondary p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setAct("BUY"),
					className: `h-9 flex-1 rounded-md text-xs font-medium ${act === "BUY" ? "bg-up text-background" : "text-muted-foreground"}`,
					children: "Buy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setAct("SELL"),
					className: `h-9 flex-1 rounded-md text-xs font-medium ${act === "SELL" ? "bg-down text-white" : "text-muted-foreground"}`,
					children: "Sell"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Quantity" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: qty,
							onChange: (e) => setQty(e.target.value),
							inputMode: "numeric"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Limit" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: limit,
							placeholder: formatPrice(px),
							onChange: (e) => setLimit(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Stop" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: stopPx,
							onChange: (e) => setStopPx(e.target.value),
							placeholder: "Required"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Target" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: tgt,
							onChange: (e) => setTgt(e.target.value)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] text-muted-foreground",
				children: "Limit only · paper · Indian cost model applied on fill. Risk engine can reject."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				onClick: submit,
				variant: act === "BUY" ? "up" : "down",
				className: "w-full",
				children: [
					"Paper ",
					act.toLowerCase(),
					" ",
					inst.symbol
				]
			})
		]
	});
}
//#endregion
export { OrderTicket as n, Input as t };
