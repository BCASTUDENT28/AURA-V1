//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cu_i1ahb.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/lab",
			"/memory",
			"/more",
			"/news",
			"/paper",
			"/portfolio",
			"/research",
			"/risk",
			"/signals"
		],
		preloads: [
			"/assets/index-2_c1PFyy.js",
			"/assets/jsx-runtime-B-hcVAMW.js",
			"/assets/dist-njREzD9H.js",
			"/assets/link-3BkJfc5N.js",
			"/assets/preload-helper-Atzj9QdZ.js",
			"/assets/createLucideIcon-ChDqWVJv.js",
			"/assets/aura-store-DyRFMthK.js",
			"/assets/dist-Bgc49-9k.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-2_c1PFyy.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-UocQGzef.js",
			"/assets/signal-detail-C2jN8jNy.js",
			"/assets/card-KWyzMo_D.js"
		]
	},
	"/lab": {
		filePath: "/workspace/src/routes/lab.tsx",
		children: void 0,
		preloads: [
			"/assets/lab-BXZ9iobf.js",
			"/assets/button-CboyOpVV.js",
			"/assets/card-KWyzMo_D.js",
			"/assets/generateCategoricalChart-C2s7xMX0.js"
		]
	},
	"/memory": {
		filePath: "/workspace/src/routes/memory.tsx",
		children: void 0,
		preloads: ["/assets/memory-BrbLV1MN.js", "/assets/card-KWyzMo_D.js"]
	},
	"/more": {
		filePath: "/workspace/src/routes/more.tsx",
		children: void 0,
		preloads: ["/assets/more-Bhx-0wYv.js"]
	},
	"/news": {
		filePath: "/workspace/src/routes/news.tsx",
		children: void 0,
		preloads: ["/assets/news-C3zr65kx.js", "/assets/card-KWyzMo_D.js"]
	},
	"/paper": {
		filePath: "/workspace/src/routes/paper.tsx",
		children: void 0,
		preloads: [
			"/assets/paper-DxgWRbRj.js",
			"/assets/button-CboyOpVV.js",
			"/assets/order-ticket-mlgCMsy2.js",
			"/assets/card-KWyzMo_D.js"
		]
	},
	"/portfolio": {
		filePath: "/workspace/src/routes/portfolio.tsx",
		children: void 0,
		preloads: [
			"/assets/portfolio-D522Ltpt.js",
			"/assets/card-KWyzMo_D.js",
			"/assets/generateCategoricalChart-C2s7xMX0.js"
		]
	},
	"/research": {
		filePath: "/workspace/src/routes/research.tsx",
		children: void 0,
		preloads: [
			"/assets/research-DS_7x3vg.js",
			"/assets/button-CboyOpVV.js",
			"/assets/card-KWyzMo_D.js"
		]
	},
	"/risk": {
		filePath: "/workspace/src/routes/risk.tsx",
		children: void 0,
		preloads: [
			"/assets/risk-27u1cgqn.js",
			"/assets/button-CboyOpVV.js",
			"/assets/card-KWyzMo_D.js"
		]
	},
	"/signals": {
		filePath: "/workspace/src/routes/signals.tsx",
		children: void 0,
		preloads: [
			"/assets/signals-CWGThTo-.js",
			"/assets/signal-detail-C2jN8jNy.js",
			"/assets/order-ticket-mlgCMsy2.js",
			"/assets/card-KWyzMo_D.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
